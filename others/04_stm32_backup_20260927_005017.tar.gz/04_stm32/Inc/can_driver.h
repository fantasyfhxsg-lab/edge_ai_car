/**
 * can_driver.h - CAN驱动抽象层（CAN Driver Abstraction）
 *
 * 硬件：CAN1 @ PA11(RX)/PA12(TX)，500kbps
 *   最小系统板没有板载 CAN 收发器，必须外接 TJA1050/SN65HVD230 模块：
 *     STM32 PA12(TX) -> 收发器 TXD
 *     STM32 PA11(RX) <- 收发器 RXD
 *     收发器 CANH/CANL -> 总线；收发器 VCC 5V/3.3V 与系统共地
 *
 * 接口风格与脚手架一致：Can_Send() / Can_RegisterRxCallback() /
 * Can_SendStatus() / Can_SendHeartbeat()。
 * 接收采用轮询（Can_ProcessRx 在 10ms 任务里调用），回调签名不变。
 */
#ifndef CAN_DRIVER_H
#define CAN_DRIVER_H

#include "platform.h"
#include "can_protocol.h"

#define CAN_BITRATE_BPS    500000u
#define CAN_MAX_DATA_LEN   8u

/* ===== 接收回调函数类型 ===== */
typedef void (*Can_RxCallback_t)(uint16 can_id, const uint8* data, uint8 len);

/* ===== 初始化 ===== */
boolean Can_Init(void);

/* ===== 发送 ===== */
boolean Can_Send(uint16 can_id, const uint8* data, uint8 len);

/* ===== 接收回调注册 ===== */
void Can_RegisterRxCallback(Can_RxCallback_t callback);

/* ===== 轮询接收（在 10ms 任务中调用） ===== */
void Can_ProcessRx(void);

/* ===== 状态查询 ===== */
boolean Can_IsBusOff(void);
uint8 Can_GetTxErrorCount(void);
uint8 Can_GetRxErrorCount(void);

/* ===== 便捷发送函数 ===== */
void Can_SendStatus(uint8 status_word, sint8 current_speed, uint8 voltage_x10, uint8 fault_code);
void Can_SendHeartbeat(uint8 counter);

#endif /* CAN_DRIVER_H */
