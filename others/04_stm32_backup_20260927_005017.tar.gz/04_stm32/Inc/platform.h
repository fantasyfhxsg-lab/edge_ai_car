/**
 * platform.h - 平台抽象层（Platform Abstraction Layer）
 *
 * ═══════════ 这个头文件是"全局工具箱" ═══════════
 * 所有驱动文件（motor/servo/can/encoder）都 include 它，提供：
 *   1. 类型别名    : uint8/sint16/boolean...（和脚手架/AUTOSAR 风格一致）
 *   2. 板级常量    : LED 引脚、SYSTEM_CLOCK_HZ
 *   3. 基础服务    : SystemClock_Config / millis / delay_ms / uart_printf
 *   4. GPIO 助手   : gpio_enable_clock / gpio_mode / gpio_af / gpio_write
 *                    （寄存器级内联函数，见文件后段）
 *   5. 外设寄存器  : 来自 Core/Inc/stm32f407_regs.h
 *
 * 本版本说明（v2，适配 STM32F407ZGT6 最小系统板）：
 *   - 不再依赖 CubeMX / HAL：底层为寄存器级实现（Core/Inc/stm32f407_regs.h）
 *   - 保留脚手架的 AUTOSAR 风格类型别名（uint8/sint8/boolean...），
 *     上层业务代码写法不变
 *   - 提供时钟 / 延时 / 调试串口 / GPIO 助手
 *
 * 若日后要迁 AUTOSAR：业务代码不动，把下面这些接口换成 MCAL 实现即可。
 */
#ifndef PLATFORM_H
#define PLATFORM_H

#include "stm32f407_regs.h"
#include <stdint.h>
#include <stdarg.h>
// #include <stdio.h>

/* ===== 通用类型别名（与脚手架/AUTOSAR Std_Types.h 对齐） ===== */
typedef uint8_t  uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
typedef uint64_t uint64;
typedef int8_t   sint8;
typedef int16_t  sint16;
typedef int32_t  sint32;
typedef float    float32;
typedef double   float64;

#ifndef TRUE
#define TRUE  1u
#endif
#ifndef FALSE
#define FALSE 0u
#endif
typedef uint8 boolean;

/* ===== 常用宏 ===== */
#define UNUSED(x)  ((void)(x))

/* ===== 系统时钟频率 ===== */
#define SYSTEM_CLOCK_HZ  168000000u   /* HSE 8MHz -> PLL 168MHz */

/* ================================================================
 * 平台基础服务（寄存器级实现，定义在 main.c）
 * ================================================================ */
void    SystemClock_Config(void);   /* 系统时钟 168MHz */
void    SysTick_Init(void);         /* 1ms 心跳 */
uint32  millis(void);               /* 上电以来毫秒 */
void    delay_ms(uint32 ms);        /* 阻塞延时 */

/* 调试串口 USART1 @ PA9(TX)/PA10(RX), 115200 8N1 */
void    UART1_Init(void);
void    uart_putc(char c);
void    uart_puts(const char *s);
void    uart_printf(const char *fmt, ...);

/* ===== 板载 LED =====
 * M144Z-M4（正点原子 STM32F407 Mini板）：LED0=PF9(红)、LED1=PF10(绿)，低电平点亮。
 * 代码使用 LED0(PF9)。若你的板子不同，改这里；没有 LED 也不影响运行。
 */
#define LED_PORT GPIOF
#define LED_PIN  GPIO_PIN_9
#define LED_ON()   (LED_PORT->BSRR = (uint32)(LED_PIN) << 16)   /* 输出低 -> 点亮 */
#define LED_OFF()  (LED_PORT->BSRR = (uint32)(LED_PIN))         /* 输出高 -> 熄灭 */

/* ================================================================
 * GPIO 助手（寄存器级）
 * ================================================================ */
static inline void gpio_enable_clock(GPIO_TypeDef *port)
{
    if (port == GPIOA)      RCC->AHB1ENR |= RCC_GPIOAEN;
    else if (port == GPIOB) RCC->AHB1ENR |= RCC_GPIOBEN;
    else if (port == GPIOC) RCC->AHB1ENR |= RCC_GPIOCEN;
    else if (port == GPIOD) RCC->AHB1ENR |= RCC_GPIODEN;
    else if (port == GPIOE) RCC->AHB1ENR |= RCC_GPIOEEN;
    else if (port == GPIOF) RCC->AHB1ENR |= RCC_GPIOFEN;
    else if (port == GPIOG) RCC->AHB1ENR |= RCC_GPIOGEN;
}

// static inline void gpio_mode(GPIO_TypeDef *port, uint16 pin, uint8 mode)
// {
//     uint32 pos = 0;
//     while (!(pin & (1U << pos))) pos++;
//     port->MODER &= ~(3U << (pos * 2));
//     port->MODER |=  ((uint32)mode << (pos * 2));
// }

static inline void gpio_mode(GPIO_TypeDef *port, uint16 pin, uint8 mode)
{
    uint32 pos = 0;
    while (pin) {
        if (pin & 1U) {
            port->MODER &= ~(3U << (pos * 2));
            port->MODER |=  ((uint32)mode << (pos * 2));
        }
        pin >>= 1;
        pos++;
    }
}

static inline void gpio_af(GPIO_TypeDef *port, uint16 pin, uint8 af)
{
    uint32 pos = 0;
    while (!(pin & (1U << pos))) pos++;
    if (pos < 8) {
        port->AFRL &= ~(0xFU << (pos * 4));
        port->AFRL |=  ((uint32)af << (pos * 4));
    } else {
        pos -= 8;
        port->AFRH &= ~(0xFU << (pos * 4));
        port->AFRH |=  ((uint32)af << (pos * 4));
    }
}

static inline void gpio_write(GPIO_TypeDef *port, uint16 pin, uint8 level)
{
    if (level) port->BSRR = (uint32)pin;          /* 置 1 */
    else       port->BSRR = (uint32)pin << 16;    /* 清 0 */
}

static inline uint8 gpio_read(GPIO_TypeDef *port, uint16 pin)
{
    return (port->IDR & pin) ? 1 : 0;
}

#endif /* PLATFORM_H */
