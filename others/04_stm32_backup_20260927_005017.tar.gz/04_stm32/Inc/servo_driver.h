/**
 * servo_driver.h - 舵机驱动抽象层（Servo Driver Abstraction）
 *
 * 硬件：MG996R 舵机，50Hz PWM
 *   PA8 = TIM1_CH1（高级定时器，需开 MOE）
 *   TIM1 时钟 168MHz：PSC=167 -> 1MHz，ARR=19999 -> 50Hz
 *   CCR 数值 = 脉冲宽度(us)，中位 1500us，范围 1000~2000us
 *
 * 供电：舵机必须独立 5-6V 供电（MG996R 峰值电流可达 2A+），
 *       严禁从 STM32 3.3V 取电！GND 与系统共地。
 */
#ifndef SERVO_DRIVER_H
#define SERVO_DRIVER_H

#include "platform.h"

/* ===== 舵机参数配置 ===== */
#define SERVO_PWM_FREQ_HZ        50u
#define SERVO_CENTER_PULSE_US    1500u
#define SERVO_MAX_LEFT_PULSE_US  2000u     /* +角度方向 = 右转（按需对调） */
#define SERVO_MAX_RIGHT_PULSE_US 1000u
#define SERVO_MAX_ANGLE_DEG      30

/* ===== 初始化 ===== */
void Servo_Init(void);

/* ===== 角度控制 ===== */
void Servo_SetAngle(sint8 angle);   /* -30~+30 度，0=中位 */
sint8 Servo_GetAngle(void);

/* ===== 直接脉冲控制（底层调试用） ===== */
void Servo_SetPulse(uint16 pulse_us);

/* ===== 自检 ===== */
boolean Servo_SelfTest(void);

#endif /* SERVO_DRIVER_H */
