/**
 * motor_driver.h - 电机驱动抽象层（Motor Driver Abstraction）
 *
 * 硬件：TB6612FNG 双通道 H 桥
 *   A通道(左轮): PWMA=PA6(TIM3_CH1), AIN1=PB0, AIN2=PB1
 *   B通道(右轮): PWMB=PA7(TIM3_CH2), BIN1=PB4, BIN2=PB5
 *   STBY=PB3（必须拉高）
 *
 * 接口风格与脚手架一致：业务层只调用 Motor_xxx()，不直接碰寄存器。
 */
#ifndef MOTOR_DRIVER_H
#define MOTOR_DRIVER_H

#include "platform.h"

/* ===== 电机状态定义 ===== */
typedef enum {
    MOTOR_STATE_STOP = 0,    /* 停止     */
    MOTOR_STATE_FORWARD,     /* 正转     */
    MOTOR_STATE_REVERSE,     /* 反转     */
    MOTOR_STATE_BRAKE        /* 急刹(短路制动) */
} MotorState_t;

/* ===== 初始化 ===== */
void Motor_Init(void);

/* ===== 速度控制（阿克曼：两轮同速） ===== */
/**
 * @brief 设置电机速度（两轮同速，带方向，带斜坡）
 * @param speed -1000~1000；正=前进，负=后退，0=停止
 * @note  内部带 20ms 斜坡限幅，防止上电冲击
 */
void Motor_SetSpeed(sint16 speed);

/**
 * @brief 左右轮独立设置（调试差速用）
 */
void Motor_SetSpeedLR(sint16 left, sint16 right);

sint16 Motor_GetSpeed(void);

/* ===== 急刹控制 ===== */
void Motor_EmergencyBrake(void);
void Motor_ReleaseBrake(void);

/* ===== 状态查询 ===== */
MotorState_t Motor_GetState(void);
boolean Motor_SelfTest(void);

#endif /* MOTOR_DRIVER_H */
