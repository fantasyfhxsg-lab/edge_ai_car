/**
 * encoder.h - 编码器抽象层（Encoder Abstraction）
 *
 * 硬件：JGB37-520 霍尔编码器（11 PPR 电机轴 × 减速比 19 = 209 PPR 输出轴）
 *   左轮: TIM4 编码器模式，PD12(TIM4_CH1)/PD13(TIM4_CH2)
 *   右轮: TIM8 编码器模式，PC6 (TIM8_CH1)/PC7 (TIM8_CH2)
 *   正交 4 倍频：输出轴每转计数值 = 209 × 4 = 836
 *
 * 接口：默认 API 操作左轮，新增 _Right 后缀操作右轮。
 */
#ifndef ENCODER_H
#define ENCODER_H

#include "platform.h"

/* ===== 编码器参数（JGB37-520） ===== */
#define ENCODER_PPR           836u   /* = 11 × 19 × 4（输出轴每转计数值） */
#define ENCODER_CONTROL_PERIOD_MS 20u
#define WHEEL_DIAMETER_MM     65u

/* ===== 初始化 ===== */
void Encoder_Init(void);

/* ===== 左轮（默认 API） ===== */
sint16 Encoder_GetCount(void);
sint16 Encoder_GetDelta(void);
float32 Encoder_GetSpeedRPM(void);
float32 Encoder_GetSpeedCmPerS(void);
void   Encoder_Reset(void);
boolean Encoder_SelfTest(void);

/* ===== 右轮 ===== */
sint16  Encoder_GetCountRight(void);
sint16  Encoder_GetDeltaRight(void);
float32 Encoder_GetSpeedRPMRight(void);

#endif /* ENCODER_H */
