/**
 * stm32f407_regs.h - STM32F407 寄存器定义（自包含，免 HAL/CubeMX）
 *
 * ═══════════ 读这个文件前先懂两件事 ═══════════
 * 1. Cortex-M4 外设就是"内存映射的寄存器"：每个外设占用一段地址，
 *    用结构体指针（如 GPIOA）访问其寄存器，写特定 bit 就是配置。
 *    地址查 RM0090 的 "memory map" 章节，本文件只抄了用到的：
 *       AHB1:  GPIOA~G (0x40020000~0x40021800)、RCC(0x40023800)
 *       APB1:  TIM2/3/4/5、USART2 等（42MHz 域）
 *       APB2:  TIM1/8、USART1（84MHz 域）
 *       CAN1:  APB1 + 0x6400
 * 2. 为什么要自己定义？CubeMX/HAL 会带来几百个文件；
 *    这个工程只用 6 个外设（GPIO/RCC/TIM1/3/4/8/CAN1/USART1），
 *    手写 400 行寄存器宏就够，WSL 里 make 直出，无需 Windows 工具。
 *
 * 依据：RM0090 Reference Manual
 * 说明：只定义本工程用到的外设寄存器
 */
#ifndef STM32F407_REGS_H
#define STM32F407_REGS_H

#include <stdint.h>

/* ================= 地址基址 ================= */
#define FLASH_BASE        0x08000000UL
#define SRAM_BASE         0x20000000UL
#define PERIPH_BASE       0x40000000UL
#define APB1PERIPH_BASE   (PERIPH_BASE + 0x00000000UL)
#define APB2PERIPH_BASE   (PERIPH_BASE + 0x00010000UL)
#define AHB1PERIPH_BASE   (PERIPH_BASE + 0x00020000UL)
#define GPIOA_BASE        (AHB1PERIPH_BASE + 0x0000UL)
#define GPIOB_BASE        (AHB1PERIPH_BASE + 0x0400UL)
#define GPIOC_BASE        (AHB1PERIPH_BASE + 0x0800UL)
#define GPIOD_BASE        (AHB1PERIPH_BASE + 0x0C00UL)
#define GPIOE_BASE        (AHB1PERIPH_BASE + 0x1000UL)
#define GPIOF_BASE        (AHB1PERIPH_BASE + 0x1400UL)
#define GPIOG_BASE        (AHB1PERIPH_BASE + 0x1800UL)
#define RCC_BASE          (AHB1PERIPH_BASE + 0x3800UL)
#define TIM2_BASE         (APB1PERIPH_BASE + 0x0000UL)
#define TIM3_BASE         (APB1PERIPH_BASE + 0x0400UL)
#define TIM4_BASE         (APB1PERIPH_BASE + 0x0800UL)
#define TIM5_BASE         (APB1PERIPH_BASE + 0x0C00UL)
#define USART1_BASE       (APB2PERIPH_BASE + 0x1000UL)
#define TIM1_BASE         (APB2PERIPH_BASE + 0x0000UL)
#define TIM8_BASE         (APB2PERIPH_BASE + 0x0400UL)
#define CAN1_BASE         (APB1PERIPH_BASE + 0x6400UL)

/* ================= GPIO ================= */
#define GPIO_PIN_0  0x0001U
#define GPIO_PIN_1  0x0002U
#define GPIO_PIN_2  0x0004U
#define GPIO_PIN_3  0x0008U
#define GPIO_PIN_4  0x0010U
#define GPIO_PIN_5  0x0020U
#define GPIO_PIN_6  0x0040U
#define GPIO_PIN_7  0x0080U
#define GPIO_PIN_8  0x0100U
#define GPIO_PIN_9  0x0200U
#define GPIO_PIN_10 0x0400U
#define GPIO_PIN_11 0x0800U
#define GPIO_PIN_12 0x1000U
#define GPIO_PIN_13 0x2000U
#define GPIO_PIN_14 0x4000U
#define GPIO_PIN_15 0x8000U

#define GPIO_MODE_INPUT  0x00U
#define GPIO_MODE_OUTPUT 0x01U
#define GPIO_MODE_AF     0x02U
#define GPIO_MODE_ANALOG 0x03U

// 新增：__IO 宏定义，CMSIS标准
#define __IO volatile
#define __I  volatile const
#define __O  volatile

typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t OTYPER;
    volatile uint32_t OSPEEDR;
    volatile uint32_t PUPDR;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t LCKR;
    volatile uint32_t AFRL;
    volatile uint32_t AFRH;
} GPIO_TypeDef;

#define GPIOA ((GPIO_TypeDef *)GPIOA_BASE)
#define GPIOB ((GPIO_TypeDef *)GPIOB_BASE)
#define GPIOC ((GPIO_TypeDef *)GPIOC_BASE)
#define GPIOD ((GPIO_TypeDef *)GPIOD_BASE)
#define GPIOE ((GPIO_TypeDef *)GPIOE_BASE)
#define GPIOF ((GPIO_TypeDef *)GPIOF_BASE)
#define GPIOG ((GPIO_TypeDef *)GPIOG_BASE)

/* ================= RCC ================= */
typedef struct {
    volatile uint32_t CR;
    volatile uint32_t PLLCFGR;
    volatile uint32_t CFGR;
    volatile uint32_t CIR;
    volatile uint32_t AHB1RSTR;
    volatile uint32_t AHB2RSTR;
    volatile uint32_t AHB3RSTR;
    volatile uint32_t RESERVED0;
    volatile uint32_t APB1RSTR;
    volatile uint32_t APB2RSTR;
    volatile uint32_t RESERVED1;
    volatile uint32_t RESERVED2;
    volatile uint32_t AHB1ENR;
    volatile uint32_t AHB2ENR;
    volatile uint32_t AHB3ENR;
    volatile uint32_t RESERVED3;
    volatile uint32_t APB1ENR;
    volatile uint32_t APB2ENR;
    volatile uint32_t RESERVED4;
    volatile uint32_t RESERVED5;
    volatile uint32_t AHB1LPENR;
    volatile uint32_t AHB2LPENR;
    volatile uint32_t AHB3LPENR;
    volatile uint32_t RESERVED6;
    volatile uint32_t APB1LPENR;
    volatile uint32_t APB2LPENR;
    volatile uint32_t RESERVED7;
    volatile uint32_t RESERVED8;
    volatile uint32_t BDCR;
    volatile uint32_t CSR;
} RCC_TypeDef;

#define RCC_GPIOAEN  (1U << 0)
#define RCC_GPIOBEN  (1U << 1)
#define RCC_GPIOCEN  (1U << 2)
#define RCC_GPIODEN  (1U << 3)
#define RCC_GPIOEEN  (1U << 4)
#define RCC_GPIOFEN  (1U << 5)
#define RCC_GPIOGEN  (1U << 6)
#define RCC_TIM1EN   (1U << 0)
#define RCC_TIM8EN   (1U << 1)
#define RCC_USART1EN (1U << 4)
#define RCC_TIM2EN   (1U << 0)
#define RCC_TIM3EN   (1U << 1)
#define RCC_TIM4EN   (1U << 2)
#define RCC_CAN1EN   (1U << 25)

#define RCC ((RCC_TypeDef *)RCC_BASE)

/* ================= 通用定时器 TIM2/3/4/5 ================= */
typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RESERVED0;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
} TIM_TypeDef;

#define TIM2 ((TIM_TypeDef *)TIM2_BASE)
#define TIM3 ((TIM_TypeDef *)TIM3_BASE)
#define TIM4 ((TIM_TypeDef *)TIM4_BASE)

/* ================= 高级定时器 TIM1/TIM8 ================= */
typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RCR;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
    volatile uint32_t BDTR;
    volatile uint32_t DCR;
    volatile uint32_t DMAR;
} TIM_AdvTypeDef;

#define TIM1 ((TIM_AdvTypeDef *)TIM1_BASE)
#define TIM8 ((TIM_AdvTypeDef *)TIM8_BASE)

/* TIM 常用位 */
#define TIM_CR1_CEN      (1U << 0)
#define TIM_CR1_ARPE     (1U << 7)
#define TIM_SMCR_SMS     (3U << 0)     /* 编码器模式 3 = 11 */
#define TIM_CCMR1_IC1F   (0x0FU << 4)  /* 输入滤波 */
#define TIM_CCMR1_CC1S   (3U << 0)     /* 输入捕获1选择 */
#define TIM_CCMR1_CC2S   (3U << 8)
#define TIM_CCMR1_OC1M   (6U << 4)     /* 输出比较1模式 */
#define TIM_CCMR1_OC2M   (6U << 12)
#define TIM_CCMR1_OC1PE  (1U << 3)
#define TIM_CCMR1_OC2PE  (1U << 11)
#define TIM_CCER_CC1E    (1U << 0)
#define TIM_CCER_CC2E    (1U << 4)
#define TIM_CCER_CC1P    (1U << 1)
#define TIM_CCER_CC2P    (1U << 5)
#define TIM_BDTR_MOE     (1U << 15)

/* ================= USART ================= */
typedef struct {
    volatile uint32_t SR;
    volatile uint32_t DR;
    volatile uint32_t BRR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t CR3;
    volatile uint32_t GTPR;
} USART_TypeDef;

#define USART1 ((USART_TypeDef *)USART1_BASE)
#define USART_SR_TXE  (1U << 7)
#define USART_SR_TC   (1U << 6)
#define USART_SR_RXNE (1U << 5)
#define USART_CR1_UE  (1U << 13)
#define USART_CR1_TE  (1U << 3)
#define USART_CR1_RE  (1U << 2)

/* ================= CAN1 ================= */
/* 寄存器偏移严格按 RM0090：邮箱 = TIR/TDTR/TDLR/TDHR */
typedef struct {
    volatile uint32_t MCR;      /* 0x00 */
    volatile uint32_t MSR;      /* 0x04 */
    volatile uint32_t TSR;      /* 0x08 */
    volatile uint32_t RF0R;     /* 0x0C */
    volatile uint32_t RF1R;     /* 0x10 */
    volatile uint32_t IER;      /* 0x14 */
    volatile uint32_t ESR;      /* 0x18 */
    volatile uint32_t BTR;      /* 0x1C */
    volatile uint32_t RESERVED0[24];  /* 0x20-0x7C */
    volatile uint32_t TX0R;     /* 0x80 TIR0 */
    volatile uint32_t TX0D0;    /* 0x84 TDTR0 (DLC) */
    volatile uint32_t TX0D1;    /* 0x88 TDLR0 (字节0-3) */
    volatile uint32_t TX0D2;    /* 0x8C TDHR0 (字节4-7) */
    volatile uint32_t TX1R;     /* 0x90 TIR1 */
    volatile uint32_t TX1D0;    /* 0x94 TDTR1 */
    volatile uint32_t TX1D1;    /* 0x98 TDLR1 */
    volatile uint32_t TX1D2;    /* 0x9C TDHR1 */
    volatile uint32_t TX2R;     /* 0xA0 TIR2 */
    volatile uint32_t TX2D0;    /* 0xA4 TDTR2 */
    volatile uint32_t TX2D1;    /* 0xA8 TDLR2 */
    volatile uint32_t TX2D2;    /* 0xAC TDHR2 */
    volatile uint32_t RX0R;     /* 0xB0 RIR0 */
    volatile uint32_t RX0D0;    /* 0xB4 RDTR0 (DLC) */
    volatile uint32_t RX0D1;    /* 0xB8 RDLR0 (字节0-3) */
    volatile uint32_t RX0D2;    /* 0xBC RDHR0 (字节4-7) */
    volatile uint32_t RX1R;     /* 0xC0 RIR1 */
    volatile uint32_t RX1D0;    /* 0xC4 RDTR1 */
    volatile uint32_t RX1D1;    /* 0xC8 RDLR1 */
    volatile uint32_t RX1D2;    /* 0xCC RDHR1 */
    volatile uint32_t RESERVED1[76];  /* 0xD0-0x1FC */
    volatile uint32_t FMR;      /* 0x200 */
    volatile uint32_t FM1R;     /* 0x204 */
    volatile uint32_t FM2R;     /* 0x208 */
    volatile uint32_t FS1R;     /* 0x20C */
    volatile uint32_t FS2R;     /* 0x210 */
    volatile uint32_t FFA1R;    /* 0x214 */
    volatile uint32_t FFA2R;    /* 0x218 */
    volatile uint32_t FA1R;     /* 0x21C */
    volatile uint32_t FA2R;     /* 0x220 */
    volatile uint32_t RESERVED2[6];   /* 0x224-0x23C */
    volatile uint32_t F0R1;     /* 0x240 */
    volatile uint32_t F0R2;     /* 0x244 */
    volatile uint32_t F1R1;     /* 0x248 */
    volatile uint32_t F1R2;     /* 0x24C */
} CAN_TypeDef;

#define CAN1 ((CAN_TypeDef *)CAN1_BASE)

/* CAN MCR */
#define CAN_MCR_INRQ   (1U << 0)
#define CAN_MCR_SLEEP  (1U << 1)
#define CAN_MCR_TXFP   (1U << 2)
#define CAN_MCR_RFLM   (1U << 3)
#define CAN_MCR_NART   (1U << 4)
#define CAN_MCR_AWUM   (1U << 5)
#define CAN_MCR_ABOM   (1U << 6)
#define CAN_MCR_TTCM   (1U << 7)
#define CAN_MCR_RESET  (1U << 15)
#define CAN_MCR_DBF    (1U << 16)
/* CAN MSR */
#define CAN_MSR_INAK   (1U << 0)
#define CAN_MSR_SLAK   (1U << 1)
#define CAN_MSR_ERRI   (1U << 2)
#define CAN_MSR_TXM    (1U << 8)
#define CAN_MSR_RXM    (1U << 9)
#define CAN_MSR_SAMP   (1U << 10)
#define CAN_MSR_RX     (1U << 11)
/* CAN TSR */
#define CAN_TSR_TME0   (1U << 26)
#define CAN_TSR_TME1   (1U << 27)
#define CAN_TSR_TME2   (1U << 28)
#define CAN_TSR_TME    (CAN_TSR_TME0 | CAN_TSR_TME1 | CAN_TSR_TME2)
/* CAN RF0R */
#define CAN_RF0R_FMP0  (3U << 0)
#define CAN_RF0R_FULL0 (1U << 3)
#define CAN_RF0R_FOVR0 (1U << 4)
#define CAN_RF0R_RFOM0 (1U << 5)
/* CAN IER */
#define CAN_IER_FMPIE0 (1U << 1)
/* CAN ESR */
#define CAN_ESR_EWGF   (1U << 0)
#define CAN_ESR_EPVF   (1U << 1)
#define CAN_ESR_BOFF   (1U << 2)
#define CAN_ESR_TEC    (0xFFU << 16)
#define CAN_ESR_REC    (0xFFU << 24)
/* CAN FMR */
#define CAN_FMR_FINIT  (1U << 0)
/* CAN FA1R: 过滤器激活 */

/* ================= 其他 ================= */
/* Flash 接口寄存器区（RM0090: 0x40023C00） */
#define FLASH_R_BASE 0x40023C00UL
#define FLASH_ACR ((volatile uint32_t *)(FLASH_R_BASE + 0x00UL))
#define FLASH_ACR_ICEN   (1U << 9)
#define FLASH_ACR_DCEN   (1U << 10)
#define FLASH_ACR_LATENCY_MASK (0x7U)
#define FLASH_ACR_LATENCY_5WS  (5U << 0)

#define SCB_BASE 0xE000ED00UL
#define SCB_ACR  ((volatile uint32_t *)(SCB_BASE + 0x14UL))

#define SYSTICK_BASE 0xE000E010UL
typedef struct {
    volatile uint32_t CSR;
    volatile uint32_t RVR;
    volatile uint32_t CVR;
    volatile uint32_t CALIB;
} SysTick_TypeDef;
#define SysTick ((SysTick_TypeDef *)SYSTICK_BASE)
#define SYSTICK_CSR_ENABLE  (1U << 0)
#define SYSTICK_CSR_TICKINT (1U << 1)
#define SYSTICK_CSR_CLKSOURCE (1U << 2)

#define __WFI() __asm volatile ("wfi")

#endif /* STM32F407_REGS_H */

// SYSCFG 寄存器结构体，添加到 stm32f407_regs.h
typedef struct
{
  __IO uint32_t MEMRMP;
  __IO uint32_t PMC;
  __IO uint32_t EXTICR1;
  __IO uint32_t EXTICR2;
  __IO uint32_t EXTICR3;
  __IO uint32_t EXTICR4;
  uint32_t RESERVED1[2];
  __IO uint32_t CMPCR;
} SYSCFG_TypeDef;

#define SYSCFG_BASE         0x40013800UL
#define SYSCFG              ((SYSCFG_TypeDef *) SYSCFG_BASE)
#define RCC_APB2ENR_SYSCFGEN (1U << 14)

