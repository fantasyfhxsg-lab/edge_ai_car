    .syntax unified
    .cpu cortex-m4
    .fpu softvfp
    .thumb

.section .isr_vector,"a",%progbits
.word   _estack
.word   Reset_Handler
.word   NMI_Handler
.word   HardFault_Handler
.word   MemManage_Handler
.word   BusFault_Handler
.word   UsageFault_Handler
.word   0
.word   0
.word   0
.word   0
.word   SVC_Handler
.word   DebugMon_Handler
.word   0
.word   PendSV_Handler
.word   SysTick_Handler

/* 外部中断：只列出本工程用到的（TIM1/TIM3/TIM4/TIM8/CAN1/USART1） */
.word   0                    /* 0:  WWDG */
.word   0                    /* 1:  PVD  */
.word   0                    /* 2:  TAMP_STAMP */
.word   0                    /* 3:  RTC_WKUP */
.word   0                    /* 4:  FLASH */
.word   0                    /* 5:  RCC */
.word   0                    /* 6:  EXTI0 */
.word   0                    /* 7:  EXTI1 */
.word   0                    /* 8:  EXTI2 */
.word   0                    /* 9:  EXTI3 */
.word   0                    /* 10: EXTI4 */
.word   0                    /* 11: DMA1_Stream0 */
.word   0                    /* 12: DMA1_Stream1 */
.word   0                    /* 13: DMA1_Stream2 */
.word   0                    /* 14: DMA1_Stream3 */
.word   0                    /* 15: DMA1_Stream4 */
.word   0                    /* 16: DMA1_Stream5 */
.word   0                    /* 17: DMA1_Stream6 */
.word   0                    /* 18: DMA1_Stream7 */
.word   0                    /* 19: ADC1_2 */
.word   0                    /* 20: CAN1_TX */
.word   0                    /* 21: CAN1_RX0 */
.word   0                    /* 22: CAN1_RX1 */
.word   0                    /* 23: CAN1_SCE */
.word   0                    /* 24: EXTI9_5 */
.word   0                    /* 25: TIM1_BRK_TIM9 */
.word   0                    /* 26: TIM1_UP_TIM10 */
.word   0                    /* 27: TIM1_TRG_COM_TIM11 */
.word   0                    /* 28: TIM1_CC */
.word   0                    /* 29: TIM2 */
.word   0                    /* 30: TIM3 */
.word   0                    /* 31: TIM4 */
.word   0                    /* 32: I2C1_EV */
.word   0                    /* 33: I2C1_ER */
.word   0                    /* 34: I2C2_EV */
.word   0                    /* 35: I2C2_ER */
.word   0                    /* 36: SPI1 */
.word   0                    /* 37: SPI2 */
.word   0                    /* 38: USART1 */
.word   0                    /* 39: USART2 */
.word   0                    /* 40: USART3 */
.word   0                    /* 41: EXTI15_10 */
.word   0                    /* 42: RTC_Alarm */
.word   0                    /* 43: OTG_FS_WKUP */
.word   0                    /* 44: TIM8_BRK_TIM12 */
.word   0                    /* 45: TIM8_UP_TIM13 */
.word   0                    /* 46: TIM8_TRG_COM_TIM14 */
.word   0                    /* 47: TIM8_CC */
.word   0                    /* 48: DMA1_Stream7 */
.word   0                    /* 49: FMC */
.word   0                    /* 50: SDIO */
.word   0                    /* 51: TIM5 */
.word   0                    /* 52: SPI3 */
.word   0                    /* 53: UART4 */
.word   0                    /* 54: UART5 */
.word   0                    /* 55: TIM6_DAC */
.word   0                    /* 56: TIM7 */
.word   0                    /* 57: DMA2_Stream0 */
.word   0                    /* 58: DMA2_Stream1 */
.word   0                    /* 59: DMA2_Stream2 */
.word   0                    /* 60: DMA2_Stream3 */
.word   0                    /* 61: DMA2_Stream4 */
.word   0                    /* 62: ETH */
.word   0                    /* 63: ETH_WKUP */
.word   0                    /* 64: CAN2_TX */
.word   0                    /* 65: CAN2_RX0 */
.word   0                    /* 66: CAN2_RX1 */
.word   0                    /* 67: CAN2_SCE */
.word   0                    /* 68: OTG_FS */
.word   0                    /* 69: DMA2_Stream5 */
.word   0                    /* 70: DMA2_Stream6 */
.word   0                    /* 71: DMA2_Stream7 */
.word   0                    /* 72: USART6 */
.word   0                    /* 73: I2C3_EV */
.word   0                    /* 74: I2C3_ER */
.word   0                    /* 75: OTG_HS_EP1_OUT */
.word   0                    /* 76: OTG_HS_EP1_IN */
.word   0                    /* 77: OTG_HS_WKUP */
.word   0                    /* 78: OTG_HS */
.word   0                    /* 79: DCMI */
.word   0                    /* 80: CRYP */
.word   0                    /* 81: HASH_RNG */
.word   0                    /* 82: FPU */

    .section .text
    .thumb_func
    .global Reset_Handler
    .type Reset_Handler, %function
Reset_Handler:
    ldr r0, =_estack
    mov sp, r0

    /* 使能 FPU（Cortex-M4F） */
    ldr r0, =0xE000ED88
    ldr r1, [r0]
    orr r1, r1, #(0xF << 20)
    str r1, [r0]
    dsb
    isb

    /* 拷贝 .data 段 */
    ldr r1, =_sdata
    ldr r2, =_edata
    ldr r3, =_sidata
    b LoopCopyDataInit
CopyDataInit:
    ldr r4, [r3], #4
    str r4, [r1], #4
LoopCopyDataInit:
    cmp r1, r2
    bcc CopyDataInit

    /* 清零 .bss 段 */
    ldr r1, =_sbss
    ldr r2, =_ebss
    movs r3, #0
    b LoopFillZerobss
FillZerobss:
    str r3, [r1], #4
LoopFillZerobss:
    cmp r1, r2
    bcc FillZerobss

    bl main
    bx lr

    .thumb_func
    .weak NMI_Handler
    .weak HardFault_Handler
    .weak MemManage_Handler
    .weak BusFault_Handler
    .weak UsageFault_Handler
    .weak SVC_Handler
    .weak DebugMon_Handler
    .weak PendSV_Handler
    .weak SysTick_Handler
Default_Handler:
HardFault_Handler:
NMI_Handler:
MemManage_Handler:
BusFault_Handler:
UsageFault_Handler:
SVC_Handler:
DebugMon_Handler:
PendSV_Handler:
SysTick_Handler:
    b .
