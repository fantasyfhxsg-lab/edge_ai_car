# 04_stm32 固件说明（v2.1 - M144Z-M4 正点原子 STM32F407 Mini板）

主控：STM32F407ZGT6（LQFP144，全部引脚引出）
板载：USB转串口(CH340↔USART1)、USB SLAVE(PA11/PA12)、LED0=PF9/LED1=PF10、
      TFTLCD接口(FSMC)、OLED/摄像头接口(DCMI)、TF卡、SPI Flash、EEPROM、SRAM

# WSL 里访问 Windows 的下载文件夹，复制到工程目录
cp /mnt/c/Users/<你的Windows用户名>/Downloads/.clinerules ~/edge_ai_car/


## 硬件连接（M144Z-M4）

### TB6612FNG（电机驱动）
| TB6612 | STM32 | 说明 |
|--------|-------|------|
| PWMA   | PA6   | 左轮 PWM (TIM3_CH1, 20kHz) |
| AIN1   | PB0   | 左轮方向 |
| AIN2   | PB1   | 左轮方向 |
| PWMB   | PA7   | 右轮 PWM (TIM3_CH2, 20kHz) |
| BIN1   | PB4   | 右轮方向 |
| BIN2   | PB5   | 右轮方向 |
| STBY   | PB3   | 必须接高（悬空整片不工作！） |
| VM     | 电池+（≤13.5V，建议 3S 11.1V） | 电机电源 |
| GND    | 电池- / 系统共地 | 必须与 STM32 共地 |

### 电机（JGB37-520 ×2）
| 电机线 | 接法 |
|--------|------|
| 红/白（电机两根动力线） | TB6612 AO1/AO2（左轮）、BO1/BO2（右轮） |
| 蓝/黑（编码器电源） | 3.3V / GND（编码器支持 3.3-5V） |
| 黄/绿（编码器 A/B） | 左轮: PD12/PD13(TIM4)；右轮: PC6/PC7(TIM8) |

> 动力线红白对调 = 电机反转；编码器 A/B 对调 = 计数方向反转。

### 舵机 MG996R
| 舵机线 | 接法 |
|--------|------|
| 橙色(信号) | PA8 (TIM1_CH1) |
| 红色(V+) | 独立 5-6V BEC/降压模块（严禁用 STM32 3.3V，峰值 2A+） |
| 棕色(GND) | 系统共地 |

### CAN（板上无收发器芯片，必须外接 TJA1050 模块）
| STM32 | TJA1050/SN65HVD230 模块 |
|-------|--------------------------|
| PA12 (CAN1_TX) | TXD |
| PA11 (CAN1_RX) | RXD |
| 3.3V/5V | VCC（按模块要求） |
| GND | GND |
| - | CANH/CANL -> CAN 总线（与 USB-CAN 适配器并联） |

> ⚠ 板载 USB SLAVE 口占用 PA11/PA12（OTG_FS）。用 CAN1 时**不要插 USB SLAVE**。

### 调试串口（用板载 USB，无需外接）
M144Z-M4 板载 CH340 ↔ USART1(PA9/PA10)。跳线/拨码保持"USB串口"位置，
USB 线接板载 USB 口即出日志（115200 8N1）。若拨到"串口1"位置则需外接 USB-TTL 接 PA9/PA10。

### 用户 LED（板载）
LED0=PF9(红)、LED1=PF10(绿)，低电平点亮。代码用 LED0 做心跳闪烁。

## 编译（WSL）
```bash
sudo apt install gcc-arm-none-eabi make openocd   # 或 stlink-tools
cd 04_stm32
make
```

## 烧写（ST-Link V2）
```bash
# 方式 A
make flash
# 等价于:
# openocd -f interface/stlink.cfg -f target/stm32f4x.cfg -c "program build/car.elf verify reset exit"

# 方式 B（st-link）
make flash2
# st-flash --reset write build/car.bin 0x08000000
```

## 上电行为（Demo）
1. USART1 打印启动信息（115200，板载 USB 口可看）
2. 舵机自检：左右摆动一次回中
3. Demo 动作：前进 2s -> 刹车 -> 后退 2s -> 刹车 -> 舵机 ±30° -> 停车
4. 之后进入 10/20/100ms 任务，轮询 CAN：
   - 收到 0x100 控制帧 -> 执行（速度×10 占空比，转向映射 ±30°）
   - 收到 0x102 AI 心跳后启用 500ms 超时刹车保护
   - 每 20ms 回 0x101 状态帧，每 100ms 回 0x103 心跳

## 易错点
- STBY(PB3) 不拉高 -> 电机完全不动
- 高级定时器 TIM1 没开 MOE -> 舵机无输出（代码已处理）
- 用 CAN1 时别插 USB SLAVE 口（PA11/PA12 冲突）
- 接 TFTLCD 会占 PD12/PD13(FSMC_A11/A12)，接摄像头模块会占 PC6/PC7(DCMI) —— 小车不接没事
- 舵机不能从 STM32 3.3V 取电
- TB6612 VM 最高 13.5V，别上 4S 电池


openocd -f interface/stlink.cfg -f target/stm32f4x.cfg \
  -c "gdb_port disabled" \
  -c "init" \
  -c "reset halt" \
  -c "reg sp 0x20020000" \
  -c "reg pc 0x08000191" \
  -c "resume" \
  -c "shutdown"

项目侧操作（两种场景：手写寄存器 Makefile / CubeMX Make 工程）
⚠️ 硬性要求：代码放在 WSL 家目录 ~/xxx，不要放在 /mnt/c/ Windows 挂载目录，索引巨慢且容易出问题。
在 WSL 终端进入你的项目文件夹，用 code . 打开工程（必须 WSL 终端执行 code .）
# 场景 1：手写寄存器项目（自带 Makefile）
bash
# 清理旧编译产物 + 旧compile_commands.json
make clean
rm -f compile_commands.json

# bear捕获编译命令，自动生成compile_commands.json
bear make -j4
执行成功后，项目根目录会生成 compile_commands.json。
clangd 插件会自动识别这个文件，开始后台索引代码，右下角会出现 clangd 进度图标。

## 编译完，在 WSL 终端跑这个 (路径修正)

```
sed -i 's|"/workspace2/|"/home/fantasy/workspace2/edge_ai_car/|g' ~/workspace2/edge_ai_car/04_stm32/compile_commands.json

```

# 场景 2：CubeMX 生成 Makefile 工程
CubeMX 生成工程时，Toolchain 选：Makefile
将 CubeMX 输出的工程放到 WSL 家目录
WSL 终端进入项目目录执行：
bash
make clean
rm -f compile_commands.json
bear -- make -j4
每次在 CubeMX 修改外设、重新生成代码后，必须重新执行上面这两行，更新 compile_commands.json。
四、验证跳转功能
等待右下角 clangd 索引完成（进度条消失）
鼠标放到函数上，Ctrl + 鼠标左键，测试跳转定义；F12 跳转；Shift+F12 查找所有引用。



## 改代码后要不要重新跑？

表格

| 改了什么 | 要不要重新 bear make | 要不要跑 sed |
| --- | --- | --- |
| 只改 .c/.h 代码内容 | ❌ 不用 | ❌ 不用，clangd 自动更新 |
| 新增 / 删除 .c/.h 文件 | ✅ 要 | ✅ 要 |
| 改了 Makefile | ✅ 要 | ✅ 要 |

## 日常完整流程

```
# 终端1(容器):
cd /workspace2/04_stm32
make clean
rm -f compile_commands.json
bear make -j4

cd /workspace2/04_stm32
make clean
bear make -j4 && make flash


# 终端2(WSL):跳转失败
sed -i 's|"/workspace2/|"/home/fantasy/workspace2/edge_ai_car/|g' ~/workspace2/edge_ai_car/04_stm32/compile_commands.json
```
sed -i 's|/workspace2|/home/fantasy/workspace2/edge_ai_car|g' ~/workspace2/edge_ai_car/04_stm32/compile_commands.json

# 不折腾了，一行命令搞定，以后永远不用管，跳转成功

```
sudo ln -s /home/fantasy/workspace2/edge_ai_car /workspace2
```

- WSL 里 `/workspace2` 直接指向真实代码目录
- clangd 找 `/workspace2/04_stm32/Inc/platform.h` → 通过符号链接直接找到
- **不需要 sed, 不需要 path-mappings, 不需要清缓存，不需要重启任何东西**
- 以后容器里 `bear make` 完，直接跳转，什么都不用做
