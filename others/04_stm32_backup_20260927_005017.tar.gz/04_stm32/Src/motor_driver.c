/**
 * motor_driver.c - 电机驱动实现（TB6612FNG 双通道，寄存器级）
 *
 * ═══════════ TB6612 工作原理（读代码前先懂这个）═══════════
 * TB6612 是"两路 H 桥"：每路有 IN1/IN2 两个方向脚 + 1 个 PWM 脚。
 * 电机转速由 PWM 占空比决定，方向由 IN1/IN2 组合决定：
 *   IN1 IN2 PWM  ->  状态
 *   H   H   X       刹车(短路制动：电机两端短接，转动的轮子被强行停住)
 *   L   L   X       停止(滑行：电机悬空，惯性滚动)
 *   H   L   PWM     正转(转速∝PWM占空比)
 *   L   H   PWM     反转(转速∝PWM占空比)
 * STBY=1 整片使能，STBY=0 全部输出高阻（电机完全不工作）。
 *
 * 引脚（STM32F407ZGT6）：
 *   PWMA=PA6(TIM3_CH1)  AIN1=PB0  AIN2=PB1   -> 左轮(JGB37-520)
 *   PWMB=PA7(TIM3_CH2)  BIN1=PB4  BIN2=PB5   -> 右轮(JGB37-520)
 *   STBY=PB3（必须高电平，否则整片不工作）
 *
 * 频率计算（为什么 20kHz）：
 *   TIM3 时钟 = APB1×2 = 84MHz；PSC=83 -> 计数频率 1MHz；
 *   ARR=49 -> PWM 频率 = 1MHz/50 = 20kHz（听不见的超声频段，无啸叫）。
 *   CCR 值 0~49 就是占空比 0~100%；代码里速度 0~1000 对应 CCR 0~49，
 *   所以入口是 "speed ×10" 的换算见 main.c Task_20ms。
 *
 * 斜坡限幅 RAMP_STEP=80/20ms：速度不突变，防齿轮冲击和电流尖峰。
 */
#include "motor_driver.h"

/* ===== 内部状态 ===== */
static sint16       g_current_speed = 0;
static MotorState_t g_state = MOTOR_STATE_STOP;
static sint16       g_ramp_target = 0;

/* ===== 初始化 ===== */
void Motor_Init(void)
{
    /* STBY 拉高（整片使能） */
    gpio_enable_clock(GPIOB);
    gpio_mode(GPIOB, GPIO_PIN_3, GPIO_MODE_OUTPUT);
    gpio_write(GPIOB, GPIO_PIN_3, 1);

    /* AIN1/AIN2/BIN1/BIN2 输出 */
    gpio_mode(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5, GPIO_MODE_OUTPUT);

    /* TIM3 双通道 PWM 输出（由 main.c 的 MX_TIM3_PWM_Init 启动） */
    TIM3->CCR1 = 0;
    TIM3->CCR2 = 0;
    g_current_speed = 0;
    g_state = MOTOR_STATE_STOP;
    g_ramp_target = 0;
}

/* ===== 斜坡限幅（20ms 步进，防冲击） ===== */
#define RAMP_STEP 80
static sint16 ramp_apply(sint16 target, sint16 current)
{
    if (target > current) {
        current += RAMP_STEP;
        if (current > target) current = target;
    } else if (target < current) {
        current -= RAMP_STEP;
        if (current < target) current = target;
    }
    return current;
}

/* ===== 速度控制（两轮同速） ===== */
void Motor_SetSpeed(sint16 speed)
{
    if (speed > 1000)  speed = 1000;
    if (speed < -1000) speed = -1000;

    g_ramp_target = speed;
    g_current_speed = ramp_apply(g_ramp_target, g_current_speed);

    if (g_current_speed == 0) {
        gpio_write(GPIOB, GPIO_PIN_0, 0);
        gpio_write(GPIOB, GPIO_PIN_1, 0);
        gpio_write(GPIOB, GPIO_PIN_4, 0);
        gpio_write(GPIOB, GPIO_PIN_5, 0);
        TIM3->CCR1 = 0;
        TIM3->CCR2 = 0;
        g_state = MOTOR_STATE_STOP;
    } else if (g_current_speed > 0) {
        /* 前进：AIN1=BIN1=H, AIN2=BIN2=L */
        gpio_write(GPIOB, GPIO_PIN_0, 1);
        gpio_write(GPIOB, GPIO_PIN_1, 0);
        gpio_write(GPIOB, GPIO_PIN_4, 1);
        gpio_write(GPIOB, GPIO_PIN_5, 0);
        TIM3->CCR1 = (uint32)g_current_speed;
        TIM3->CCR2 = (uint32)g_current_speed;
        g_state = MOTOR_STATE_FORWARD;
    } else {
        /* 后退 */
        gpio_write(GPIOB, GPIO_PIN_0, 0);
        gpio_write(GPIOB, GPIO_PIN_1, 1);
        gpio_write(GPIOB, GPIO_PIN_4, 0);
        gpio_write(GPIOB, GPIO_PIN_5, 1);
        TIM3->CCR1 = (uint32)(-g_current_speed);
        TIM3->CCR2 = (uint32)(-g_current_speed);
        g_state = MOTOR_STATE_REVERSE;
    }
}

/* ===== 左右轮独立设置 ===== */
void Motor_SetSpeedLR(sint16 left, sint16 right)
{
    /* 左轮 A 通道 */
    if (left == 0) {
        gpio_write(GPIOB, GPIO_PIN_0, 0);
        gpio_write(GPIOB, GPIO_PIN_1, 0);
        TIM3->CCR1 = 0;
    } else if (left > 0) {
        gpio_write(GPIOB, GPIO_PIN_0, 1);
        gpio_write(GPIOB, GPIO_PIN_1, 0);
        TIM3->CCR1 = (uint32)left;
    } else {
        gpio_write(GPIOB, GPIO_PIN_0, 0);
        gpio_write(GPIOB, GPIO_PIN_1, 1);
        TIM3->CCR1 = (uint32)(-left);
    }

    /* 右轮 B 通道 */
    if (right == 0) {
        gpio_write(GPIOB, GPIO_PIN_4, 0);
        gpio_write(GPIOB, GPIO_PIN_5, 0);
        TIM3->CCR2 = 0;
    } else if (right > 0) {
        gpio_write(GPIOB, GPIO_PIN_4, 1);
        gpio_write(GPIOB, GPIO_PIN_5, 0);
        TIM3->CCR2 = (uint32)right;
    } else {
        gpio_write(GPIOB, GPIO_PIN_4, 0);
        gpio_write(GPIOB, GPIO_PIN_5, 1);
        TIM3->CCR2 = (uint32)(-right);
    }

    g_state = (left == 0 && right == 0) ? MOTOR_STATE_STOP :
              ((left > 0 || right > 0) ? MOTOR_STATE_FORWARD : MOTOR_STATE_REVERSE);
}

sint16 Motor_GetSpeed(void)
{
    return g_current_speed;
}

/* ===== 急刹（短路制动：IN1=IN2=H） ===== */
void Motor_EmergencyBrake(void)
{
    gpio_write(GPIOB, GPIO_PIN_0, 1);
    gpio_write(GPIOB, GPIO_PIN_1, 1);
    gpio_write(GPIOB, GPIO_PIN_4, 1);
    gpio_write(GPIOB, GPIO_PIN_5, 1);
    TIM3->CCR1 = 0;
    TIM3->CCR2 = 0;
    g_state = MOTOR_STATE_BRAKE;
    g_current_speed = 0;
    g_ramp_target = 0;
}

void Motor_ReleaseBrake(void)
{
    if (g_state == MOTOR_STATE_BRAKE) {
        g_state = MOTOR_STATE_STOP;
    }
}

MotorState_t Motor_GetState(void)
{
    return g_state;
}

/* ===== 自检（只读检查，不转电机） ===== */
boolean Motor_SelfTest(void)
{
    /* TIM3 必须已在运行 */
    if (!(TIM3->CR1 & TIM_CR1_CEN)) {
        return FALSE;
    }
    return TRUE;
}
