/**
 * can_driver.c - CAN1 驱动实现（寄存器级，免 HAL）
 *
 * ═══════════ CAN 总线速成（读代码前先懂这几条）═══════════
 * 1. CAN 是差分总线：CANH/CANL 两根线，物理层靠 TJA1050 收发器转换。
 *    本板没有板载收发器，PA11/PA12 只是控制器引脚（TTL 电平），
 *    必须外接 TJA1050：PA12=TX 接 TXD、PA11=RX 接 RXD。
 * 2. 帧格式：标准帧 = 11 位 ID + RTR + IDE + DLC(数据长度) + 0~8 字节数据。
 *    寄存器里：TIR[31:21]=ID、TIR[0]=TXRQ；TDTR[3:0]=DLC；TDLR/TDHR=数据。
 * 3. 位时序（这是理解 BTR 数值的关键）：
 *    每个位 = SYNC_SEG(1tq) + TS1 + TS2，波特率 = APB1时钟 / (BRP × (1+TS1+TS2))
 *    APB1 = 42MHz，目标 500kbps：
 *      42MHz / (BRP × (1+TS1+TS2)) = 500k
 *      取 BRP=4、TS1=15、TS2=5 -> 42M / (4 × 21) = 500kbps ✓
 *    （原脚手架注释里的 Prescaler=6/BS1=11/BS2=4 实际算出 437.5kHz，
 *      是错的，本版本已修正为 500kbps，与 can_bridge.py 对齐。）
 * 4. 发送邮箱：bxCAN 有 3 个发送邮箱(T0/T1/T2)，任一空闲即可写入，
 *    写 TIR 置 TXRQ=1 请求发送。接收有 2 个 FIFO，本驱动只用 FIFO0。
 * 5. 过滤器：F0 用掩码模式（ID=0x000, Mask=0x000）=> 不过滤，全收。
 *
 * 引脚：PA11=CAN1_RX(AF9), PA12=CAN1_TX(AF9)
 * 接收：轮询方式，Can_ProcessRx() 在 10ms 任务里调用
 */
#include "can_driver.h"
#include <stddef.h>

static Can_RxCallback_t g_rx_callback = NULL;

/* ===== CAN 初始化 ===== */
boolean Can_Init(void)
{
    /* 1. GPIO: PA11/PA12 复用 AF9 */
    gpio_enable_clock(GPIOA);
    gpio_mode(GPIOA, GPIO_PIN_11 | GPIO_PIN_12, GPIO_MODE_AF);
    gpio_af(GPIOA, GPIO_PIN_11, 9);
    gpio_af(GPIOA, GPIO_PIN_12, 9);

    /* 2. 使能 CAN1 时钟 */
    RCC->APB1ENR |= RCC_CAN1EN;

    /* 3. 初始化请求 + 等待进入初始化模式 */
    CAN1->MCR |= CAN_MCR_INRQ;
    uint32 timeout = 1000000;
    while (!(CAN1->MSR & CAN_MSR_INAK)) {
        if (--timeout == 0) return FALSE;
    }

    /* 4. 退出睡眠模式 */
    CAN1->MCR &= ~CAN_MCR_SLEEP;

    // /* 5. 配置位时序：BRP=4, TS1=15, TS2=5, SJW=1 -> 500kbps
    //  *    BTR = (BRP-1) | (TS1-1)<<16 | (TS2-1)<<20 | (SJW-1)<<24
    //  *        = 3 | 14<<16 | 4<<20 | 0<<24 = 0x4E0003
    //  */
    // CAN1->BTR = 3UL | (14UL << 16) | (4UL << 20) | (0UL << 24);

    /* 5. 配置位时序：APB1=42MHz，目标 500kbps
     *    42MHz / (BRP × (1+TS1+TS2)) = 500k
     *    取 BRP=4, TS1=15tq(寄存器写14), TS2=5tq(寄存器写4), SJW=1
     *    总 tq = 1+15+5 = 21，42MHz/(4×21)=500kbps
     *    采样点 = (1+15)/21 = 76.2%
     *    BTR = 3 | 14<<16 | 4<<20 = 0x004E0003 */
    CAN1->BTR = 3UL | (14UL << 16) | (4UL << 20) | (0UL << 24);


    /* 6. 自动总线恢复 ABOM + TX 优先级按邮箱号 */
    CAN1->MCR |= CAN_MCR_ABOM | CAN_MCR_TXFP;

    /* 7. 过滤器 0：掩码全 0（接收所有标准帧），FIFO0 */
    CAN1->FMR |= CAN_FMR_FINIT;          /* 进入过滤器初始化模式 */
    CAN1->FM1R &= ~(1UL << 0);           /* 掩码模式 */
    CAN1->FS1R |= (1UL << 0);            /* 32位过滤器 */
    CAN1->FFA1R &= ~(1UL << 0);          /* 关联 FIFO0 */
    CAN1->FA1R &= ~(1UL << 0);           /* 先失活 */
    CAN1->F0R1 = 0x00000000UL;           /* ID 全 0 */
    CAN1->F0R2 = 0x00000000UL;           /* Mask 全 0 = 全部接收 */
    CAN1->FA1R |= (1UL << 0);            /* 激活 */
    CAN1->FMR &= ~CAN_FMR_FINIT;         /* 退出过滤器初始化模式 */

    /* 8. 退出初始化模式 */
    CAN1->MCR &= ~CAN_MCR_INRQ;
    timeout = 1000000;
    while (CAN1->MSR & CAN_MSR_INAK) {
        if (--timeout == 0) return FALSE;
    }

    /* 9. 软件复位 FIFO */
    CAN1->RF0R |= CAN_RF0R_RFOM0;

    return TRUE;
}

/* ===== 发送 ===== */
boolean Can_Send(uint16 can_id, const uint8* data, uint8 len)
{
    uint32 timeout = 100000;
    volatile uint32 *tir;
    uint32 dl, dh;
    uint8 i;

    if (len > CAN_MAX_DATA_LEN) len = CAN_MAX_DATA_LEN;

    /* 等待有空邮箱（TME0/1/2 任一为 1） */
    while (!(CAN1->TSR & CAN_TSR_TME)) {
        if (--timeout == 0) return FALSE;
    }

    /* 选邮箱 */
    if (CAN1->TSR & CAN_TSR_TME0) {
        tir = &CAN1->TX0R;
    } else if (CAN1->TSR & CAN_TSR_TME1) {
        tir = &CAN1->TX1R;
    } else {
        tir = &CAN1->TX2R;
    }

    /* TIR: 标准帧(ID<<21) + 数据帧(RTR=0, IDE=0) + DLC */
    *tir = ((uint32)can_id << 21) | ((uint32)len << 0);

    /* TDTR: DLC（保险起见再写一次） */
    *(tir + 1) = (uint32)len;

    /* TDLR/TDHR: 8 字节数据 */
    dl = 0; dh = 0;
    for (i = 0; i < 8; i++) {
        if (i < len) {
            if (i < 4) dl |= ((uint32)data[i]) << (8 * i);
            else       dh |= ((uint32)data[i]) << (8 * (i - 4));
        }
    }
    *(tir + 2) = dl;
    *(tir + 3) = dh;

    /* TXRQ 请求发送 */
    *tir |= (1UL << 0);
    return TRUE;
}

/* ===== 接收回调注册 ===== */
void Can_RegisterRxCallback(Can_RxCallback_t callback)
{
    g_rx_callback = callback;
}

/* ===== 轮询接收 ===== */
void Can_ProcessRx(void)
{
    uint16 can_id;
    uint8  data[8];
    uint8  len;
    uint32 rdlr, rdhr;
    uint8  i;

    /* FIFO0 有数据（FMP0 != 0） */
    if ((CAN1->RF0R & CAN_RF0R_FMP0) == 0) return;

    can_id = (uint16)((CAN1->RX0R >> 21) & 0x7FF);   /* RIR0 */
    len = (uint8)(CAN1->RX0D0 & 0x0F);               /* RDTR0: DLC */
    if (len > 8) len = 8;

    rdlr = CAN1->RX0D1;                              /* RDLR0 */
    rdhr = CAN1->RX0D2;                              /* RDHR0 */
    for (i = 0; i < 8; i++) {
        if (i < 4) data[i] = (uint8)(rdlr >> (8 * i));
        else       data[i] = (uint8)(rdhr >> (8 * (i - 4)));
    }

    /* 释放 FIFO */
    CAN1->RF0R |= CAN_RF0R_RFOM0;

    if (g_rx_callback != NULL) {
        g_rx_callback(can_id, data, len);
    }
}

/* ===== 状态查询 ===== */
boolean Can_IsBusOff(void)
{
    return (CAN1->ESR & CAN_ESR_BOFF) ? TRUE : FALSE;
}

uint8 Can_GetTxErrorCount(void)
{
    return (uint8)((CAN1->ESR & CAN_ESR_TEC) >> 16);
}

uint8 Can_GetRxErrorCount(void)
{
    return (uint8)((CAN1->ESR & CAN_ESR_REC) >> 24);
}

/* ===== 便捷发送 ===== */
void Can_SendStatus(uint8 status_word, sint8 current_speed, uint8 voltage_x10, uint8 fault_code)
{
    uint8 data[8];

    data[0] = status_word;
    data[1] = (uint8)current_speed;
    data[2] = voltage_x10;
    data[3] = fault_code;
    data[4] = 0;   /* 编码器数据由 main.c 填充 */
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;

    Can_Send(CAN_ID_STATUS, data, 8);
}

void Can_SendHeartbeat(uint8 counter)
{
    uint8 data[8] = {0};
    data[0] = counter;
    Can_Send(CAN_ID_HEARTBEAT_STM, data, 8);
}
