/**
 * encoder.c - 编码器实现（双路，寄存器级）
 *
 * ═══════════ 编码器测速原理 ═══════════
 * JGB37-520 电机尾部霍尔编码器：电机轴每转 11 个脉冲（11PPR）。
 * 减速比 19:1 -> 输出轴每转 = 11×19 = 209 脉冲。
 * TIM 编码器模式 3（SMS=011）对 A/B 两相正交信号 4 倍频：
 *   CNT 每转计数 = 209 × 4 = 836 = ENCODER_PPR
 *
 * 测速公式（20ms 采样一次增量）：
 *   RPM = delta(脉冲数) / (836 脉冲/转) / 0.02s × 60s
 *       = delta × 3000 / 836
 *   （代码里 3000.0f 就是 60/0.02 的合并常数，见 Encoder_GetSpeedRPM）
 *
 * 引脚：
 *   左轮: TIM4 编码器模式 PD12(TIM4_CH1)/PD13(TIM4_CH2)  AF2
 *   右轮: TIM8 编码器模式 PC6 (TIM8_CH1)/PC7 (TIM8_CH2)  AF3
 *   （注意：M144Z-M4 上 PD12/13 同时连 TFTLCD 的 FSMC_A11/A12、
 *    PC6/7 连摄像头 DCMI_D0/D1——小车不插这两个模块就无冲突）
 *
 * 编码器模式 3（SMS=011）：A/B 正交 4 倍频
 * RPM = delta(20ms) × 3000 / 836
 */
#include "encoder.h"

static sint16 g_last_left = 0;
static sint16 g_last_right = 0;

/* ===== 初始化 ===== */
void Encoder_Init(void)
{
    /* ---- 左轮 TIM4：PD12=CH1, PD13=CH2 ---- */
    gpio_enable_clock(GPIOD);
    gpio_mode(GPIOD, GPIO_PIN_12 | GPIO_PIN_13, GPIO_MODE_AF);
    gpio_af(GPIOD, GPIO_PIN_12, 2);
    gpio_af(GPIOD, GPIO_PIN_13, 2);

    RCC->APB1ENR |= RCC_TIM4EN;

    TIM4->CCMR1 = (1U << 0) | (1U << 8);   /* CC1S=01, CC2S=01: TI1/TI2 输入 */
    TIM4->SMCR = TIM_SMCR_SMS;             /* 编码器模式 3（4倍频） */
    TIM4->CCER = 0;                        /* 默认极性，捕获使能由编码器模式自动 */
    TIM4->PSC = 0;
    TIM4->ARR = 0xFFFF;
    TIM4->CNT = 0;
    TIM4->CR1 = TIM_CR1_CEN;

    /* ---- 右轮 TIM8：PC6=CH1, PC7=CH2 ---- */
    gpio_enable_clock(GPIOC);
    gpio_mode(GPIOC, GPIO_PIN_6 | GPIO_PIN_7, GPIO_MODE_AF);
    gpio_af(GPIOC, GPIO_PIN_6, 3);
    gpio_af(GPIOC, GPIO_PIN_7, 3);

    RCC->APB2ENR |= RCC_TIM8EN;

    TIM8->CCMR1 = (1U << 0) | (1U << 8);
    TIM8->SMCR = TIM_SMCR_SMS;
    TIM8->CCER = 0;
    TIM8->PSC = 0;
    TIM8->ARR = 0xFFFF;
    TIM8->CNT = 0;
    TIM8->CR1 = TIM_CR1_CEN;

    g_last_left = 0;
    g_last_right = 0;
}

/* ===== 左轮 ===== */
sint16 Encoder_GetCount(void)
{
    return (sint16)TIM4->CNT;
}

sint16 Encoder_GetDelta(void)
{
    sint16 current = Encoder_GetCount();
    sint16 delta = (sint16)(current - g_last_left);
    g_last_left = current;
    return delta;
}

float32 Encoder_GetSpeedRPM(void)
{
    sint16 delta = Encoder_GetDelta();
    return ((float32)delta * 3000.0f) / (float32)ENCODER_PPR;
}

float32 Encoder_GetSpeedCmPerS(void)
{
    float32 rpm = Encoder_GetSpeedRPM();
    float32 circumference = 3.14159f * (float32)WHEEL_DIAMETER_MM / 10.0f;
    return (rpm / 60.0f) * circumference;
}

/* ===== 右轮 ===== */
sint16 Encoder_GetCountRight(void)
{
    return (sint16)TIM8->CNT;
}

sint16 Encoder_GetDeltaRight(void)
{
    sint16 current = Encoder_GetCountRight();
    sint16 delta = (sint16)(current - g_last_right);
    g_last_right = current;
    return delta;
}

float32 Encoder_GetSpeedRPMRight(void)
{
    sint16 delta = Encoder_GetDeltaRight();
    return ((float32)delta * 3000.0f) / (float32)ENCODER_PPR;
}

/* ===== 清零 ===== */
void Encoder_Reset(void)
{
    TIM4->CNT = 0;
    TIM8->CNT = 0;
    g_last_left = 0;
    g_last_right = 0;
}

/* ===== 自检 ===== */
boolean Encoder_SelfTest(void)
{
    if (!(TIM4->CR1 & TIM_CR1_CEN) || !(TIM8->CR1 & TIM_CR1_CEN)) {
        return FALSE;
    }
    return TRUE;
}
