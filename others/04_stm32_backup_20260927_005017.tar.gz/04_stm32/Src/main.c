/**
 * main.c - 运动控制 demo（无 CAN，纯跑动 + 转向）
 *
 * 适配硬件：M144Z-M4 / 正点原子 STM32F407 Mini 板（F407ZGT6, LQFP144）
 *  电机驱动 : TB6612FNG 双通道 H 桥
 *             A通道(左轮): PWMA=PA6(TIM3_CH1)  AIN1=PB0  AIN2=PB1
 *             B通道(右轮): PWMB=PA7(TIM3_CH2)  BIN1=PB4  BIN2=PB5
 *             STBY=PB3（必须拉高）
 *  电机     : JGB37-520 直流减速电机 ×2（后轮驱动）
 *  舵机     : MG996R 前轮转向，50Hz，PA8=TIM1_CH1，5~6V 独立供电
 *  调试口   : USART1 115200（板载 CH340，USB 直连看日志）
 *  LED      : LED0=PF9（低电平点亮）
 *
 * 本文件不含 CAN / 编码器 / 遥控协议，上电后自动循环演示：
 *   前进 → 刹车 → 后退 → 刹车
 *   → 左转弯(舵机左打+前进) → 右转弯(舵机右打+前进)
 *   → 原地左转(差速) → 原地右转(差速)
 *   → 舵机摆角自检 → 循环
 *
 * 说明：
 *   - 舵机角度符号（+/-30°对应左/右）取决于安装方向，若转向方向反了，
 *     把 Servo_SetAngle 的参数取反即可。
 *   - Motor_SetSpeed 内部带 20ms 斜坡限幅，起步不会窜。
 *   - 替换 04_stm32/Src/main.c 后：cd 04_stm32 && make && make flash
 */

#include "platform.h"
#include "motor_driver.h"
#include "servo_driver.h"
#include <stddef.h>

/* ================================================================
 *  时钟 / 平台基础服务（寄存器级 168MHz）
 * ================================================================ */
// void SystemClock_Config(void)
// {
//     /* 使用内部 HSI 16MHz，不依赖外部晶振 */
//     *FLASH_ACR &= ~FLASH_ACR_LATENCY_MASK;
//     *FLASH_ACR |= FLASH_ACR_ICEN | FLASH_ACR_DCEN;
//     RCC->CFGR = 0;  /* SYSCLK=HSI, AHB/APB1/APB2=1 */
// }

void SystemClock_Config(void)
{
    /* 1. Flash 等待周期 5WS + 缓存使能（168MHz 必须 5WS） */
    *FLASH_ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_LATENCY_5WS;

    /* 2. 打开 HSE 8MHz 外部晶振，等待就绪 */
    RCC->CR |= (1UL << 16);              /* HSEON */
    uint32 timeout = 1000000;
    while (!(RCC->CR & (1UL << 17))) {   /* HSERDY */
        if (--timeout == 0) break;
    }

    /* 3. 配 PLL：M=8 → 1MHz，N=336 → 336MHz，P=÷2 → 168MHz，Q=7 → 48MHz */
    RCC->PLLCFGR = (1UL << 22) | (8UL << 0) | (336UL << 6) | (0UL << 16) | (7UL << 24);

    /* 4. 打开 PLL，等待锁定 */
    RCC->CR |= (1UL << 24);              /* PLLON */
    timeout = 1000000;
    while (!(RCC->CR & (1UL << 25))) {   /* PLLRDY */
        if (--timeout == 0) break;
    }

    /* 5. 总线分频 + 选 PLL：AHB=168(÷1)，APB1=42(÷4)，APB2=84(÷2)，SW=10 */
    RCC->CFGR = (0UL << 4) | (4UL << 10) | (4UL << 13) | (2UL << 0);

    /* 6. 等待 SWS=10（PLL 生效） */
    timeout = 1000000;
    while (((RCC->CFGR >> 2) & 0x3) != 0x2) {
        if (--timeout == 0) break;
    }
}


void SysTick_Init(void)
{
    // SysTick->RVR = 16000UL - 1UL;   /* 168MHz / 168000 = 1ms */
    SysTick->RVR = 168000UL - 1UL;   /* 原 16000，168MHz / 168000 = 1ms */
    SysTick->CVR = 0;
    SysTick->CSR = SYSTICK_CSR_CLKSOURCE | SYSTICK_CSR_TICKINT | SYSTICK_CSR_ENABLE;
}

static volatile uint32 g_ticks = 0;
void SysTick_Handler(void)
{
    g_ticks++;
}

uint32 millis(void)
{
    return g_ticks;
}

void delay_ms(uint32 ms)
{
    uint32 start = millis();
    while ((millis() - start) < ms) {}
}

/* ================================================================
 *  USART1 调试串口（PA9=TX, PA10=RX, 115200 8N1）
 * ================================================================ */
void UART1_Init(void)
{
    gpio_enable_clock(GPIOA);
    gpio_mode(GPIOA, GPIO_PIN_9 | GPIO_PIN_10, GPIO_MODE_AF);
    gpio_af(GPIOA, GPIO_PIN_9, 7);
    gpio_af(GPIOA, GPIO_PIN_10, 7);

    RCC->APB2ENR |= RCC_USART1EN;

    // /* 波特率 115200: USARTDIV = 84MHz / 115200 = 729.167
    //  * BRR = 729<<4 | 3 = 11667 = 0x2D93 */
    // USART1->BRR = 0x008B;

    // /* 波特率 115200：USART1 时钟 = APB2 = 84MHz
    //  * USARTDIV = 84MHz/115200 = 729.1667 → BRR = 0x2D93（误差 0.0008%） */
    // USART1->BRR = 0x2D93;

    /* 波特率 115200：USART1 时钟 = APB2 = 84MHz
    * USARTDIV = 84e6 / (16 × 115200) = 45.57 → BRR = 0x02D9 */
    USART1->BRR = 0x02D9;



    USART1->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
}

void uart_putc(char c)
{
    while (!(USART1->SR & USART_SR_TXE)) {}
    USART1->DR = (uint32)(uint8)c;
}

void uart_puts(const char *s)
{
    while (*s) {
        uart_putc(*s++);
    }
}

void uart_printf(const char *fmt, ...)
{
    uart_puts(fmt);
}

/* ================================================================
 *  LED: LED0=PF9（低电平点亮）
 * ================================================================ */
static void MX_LED_Init(void)
{
    gpio_enable_clock(GPIOF);
    gpio_mode(GPIOF, GPIO_PIN_9, GPIO_MODE_OUTPUT);
    LED_OFF();
}

/* ================================================================
 *  TIM3: 双通道 PWM 20kHz（TB6612 PWMA/PWMB）
 *   APB1=42MHz, TIM3 时钟=84MHz, PSC=83 -> 1MHz, ARR=49 -> 20kHz
 * ================================================================ */
static void MX_TIM3_PWM_Init(void)
{
    RCC->APB1ENR |= RCC_TIM3EN;

    gpio_enable_clock(GPIOA);
    gpio_mode(GPIOA, GPIO_PIN_6 | GPIO_PIN_7, GPIO_MODE_AF);
    gpio_af(GPIOA, GPIO_PIN_6, 2);
    gpio_af(GPIOA, GPIO_PIN_7, 2);

    TIM3->PSC = 83;
    TIM3->ARR = 49;

    // TIM3->CCMR1 = TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE |   /* CH1: PWM mode 1 */
    //               TIM_CCMR1_OC2M | TIM_CCMR1_OC2PE;    /* CH2: PWM mode 1 */

    TIM3->CCMR1 = (0x6UL << 4) | TIM_CCMR1_OC1PE |     /* CH1: OC1M[6:4]=110 */
                  (0x6UL << 12) | TIM_CCMR1_OC2PE;     /* CH2: OC2M[14:12]=110 */


    TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E;
    TIM3->CCR1 = 0;
    TIM3->CCR2 = 0;
    TIM3->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
}

/* ================================================================
 *  TIM1: 舵机 PWM 50Hz（PA8=TIM1_CH1, AF1）
 *   APB2=84MHz, TIM1 时钟=168MHz, PSC=167 -> 1MHz, ARR=19999 -> 50Hz
 *   高级定时器必须置 BDTR.MOE
 * ================================================================ */
static void MX_TIM1_PWM_Init(void)
{
    RCC->APB2ENR |= RCC_TIM1EN;

    gpio_enable_clock(GPIOA);
    gpio_mode(GPIOA, GPIO_PIN_8, GPIO_MODE_AF);
    gpio_af(GPIOA, GPIO_PIN_8, 1);

    TIM1->PSC = 167;
    TIM1->ARR = 19999;

    // TIM1->CCMR1 = TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE;
    TIM1->CCMR1 = (0x6UL << 4) | TIM_CCMR1_OC1PE;    /* OC1M[6:4]=110 → PWM mode 1 */

    TIM1->CCER = TIM_CCER_CC1E;
    TIM1->CCR1 = 1500;                 /* 中位 */
    TIM1->BDTR = TIM_BDTR_MOE;         /* 主输出使能，必须有 */
    TIM1->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
}

/* ================================================================
 *  demo 动作序列（每个动作：串口提示 + 执行 + 停顿）
 * ================================================================ */
static void MotionDemo_Stop(void)
{
    Motor_SetSpeed(0);
    LED_ON();
    delay_ms(600);
    LED_OFF();
}

static void MotionDemo_Run(void)
{
    uart_puts("\r\n=== edge_ai_car 运动 demo (无 CAN) ===\r\n");
    uart_puts("电机 PWM=20kHz(TB6612) | 舵机=50Hz(MG996R)\r\n\r\n");

    while (1)
    {
        /* ---------- 1. 直线前进 / 刹车 / 后退 ---------- */
        uart_puts("[1] 前进 60% x2s\r\n");
        Motor_SetSpeed(600);
        delay_ms(2000);

        uart_puts("[2] 刹车(短路制动)\r\n");
        Motor_EmergencyBrake();
        LED_ON(); delay_ms(800); LED_OFF();
        Motor_ReleaseBrake();

        uart_puts("[3] 后退 60% x2s\r\n");
        Motor_SetSpeed(-600);
        delay_ms(2000);

        uart_puts("[4] 停车\r\n");
        MotionDemo_Stop();

        /* ---------- 2. 前轮转向（舵机打角 + 前进，阿克曼式转弯） ---------- */
        uart_puts("[5] 左转弯：舵机左打 + 前进 40% x1.5s\r\n");
        Servo_SetAngle(-30);                 /* 若方向反了，改成 +30 */
        delay_ms(500);                        /* 等舵机转到位 */
        Motor_SetSpeed(400);
        delay_ms(1500);
        Motor_SetSpeed(0);
        Servo_SetAngle(0);                    /* 回中 */
        MotionDemo_Stop();

        uart_puts("[6] 右转弯：舵机右打 + 前进 40% x1.5s\r\n");
        Servo_SetAngle(30);                  /* 若方向反了，改成 -30 */
        delay_ms(500);
        Motor_SetSpeed(400);
        delay_ms(1500);
        Motor_SetSpeed(0);
        Servo_SetAngle(0);
        MotionDemo_Stop();

        /* ---------- 3. 差速原地转圈（左右轮反向，不依赖舵机） ---------- */
        uart_puts("[7] 原地左转：左轮反转/右轮正转 x1.2s\r\n");
        Motor_SetSpeedLR(-400, 400);
        delay_ms(1200);
        Motor_SetSpeedLR(0, 0);
        MotionDemo_Stop();

        uart_puts("[8] 原地右转：左轮正转/右轮反转 x1.2s\r\n");
        Motor_SetSpeedLR(400, -400);
        delay_ms(1200);
        Motor_SetSpeedLR(0, 0);
        MotionDemo_Stop();

        /* ---------- 4. 舵机摆角测试（左右极限 + 回中） ---------- */
        uart_puts("[9] 舵机摆角：+30 -> -30 -> 0\r\n");
        Servo_SetAngle(30);  delay_ms(800);
        Servo_SetAngle(-30); delay_ms(800);
        Servo_SetAngle(0);   delay_ms(500);

        uart_puts("\r\n==== 一轮演示完成，重新开始 ====\r\n\r\n");
    }
}

/* ================================================================
 *  newlib 堆支持（-specs=nano.specs 需要 _sbrk，勿删）
 * ================================================================ */
extern char end;   /* 由链接脚本定义 */
void *_sbrk(ptrdiff_t incr)
{
    static char *heap_end = 0;
    char *prev_heap_end;

    if (heap_end == 0) {
        heap_end = &end;
    }
    prev_heap_end = heap_end;
    heap_end += incr;
    return (void *)prev_heap_end;
}

/* ================================================================
 *  main（运动 demo：无 CAN，上电直接跑）
 * ================================================================ */
int main(void)
{
    /* ===== 禁用 JTAG-DP，保留 SW-DP =====
     * PB3=JTDO、PB4=NJTRST 上电后默认是 JTAG 复用脚，
     * 即使软件把它们配成推挽输出，JTAG 外设仍会抢走引脚。
     * 本工程 PB3=STBY(TB6612 使能)、PB4=BIN1(右轮方向)，
     * 不禁用 JTAG → STBY 永远为低 → TB6612 整片待机 → AO/BO 无输出。
     * 这一步必须在所有 GPIO 配置之前执行。 */
    // RCC->APB2ENR |= RCC_SYSCFGEN;
    // SYSCFG->PMC = (SYSCFG->PMC & ~(7UL << 24)) | (2UL << 24);
    // *(volatile uint32 *)0xE000ED08 = 0x08000000UL;

    // ==========【新增：关闭JTAG，释放PB3 PB4，保留SWD】==========
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; // 开启SYSCFG外设时钟
    // SWJ_CFG[24:26] = 010：禁用JTAG，保留SWD(PA13/PA14)，PB3 PB4释放为普通GPIO
    SYSCFG->PMC &= ~(0x7UL << 24);
    SYSCFG->PMC |=  (0x1UL << 24);
    // ===========================================================

    
    /* ===== 中断向量表定位到 Flash（必须在任何中断使能之前） ===== */
    *(volatile uint32_t *)0xE000ED08 = 0x08000000;
    /* ===== 平台基础 ===== */
    SystemClock_Config();
    SysTick_Init();
    UART1_Init();
    MX_LED_Init();

    /* ===== 外设：电机 PWM + 舵机 PWM ===== */
    MX_TIM3_PWM_Init();     /* TB6612 PWMA/PWMB @20kHz */
    MX_TIM1_PWM_Init();     /* MG996R 舵机 @50Hz */

    /* ===== 驱动层 ===== */
    Motor_Init();           /* STBY=1, 初始停止(滑行) */
    Servo_Init();           /* 舵机中位 1500us */

    uart_puts("\r\nedge_ai_car motion demo boot OK @168MHz\r\n");
    uart_puts("无 CAN / 无遥控：上电自动跑动作序列\r\n\r\n");

    // /* === 加这段测试 === */
    // while (1) {
    //     LED_ON();
    //     delay_ms(500);
    //     LED_OFF();
    //     delay_ms(500);
    // }
    //ceshi
    // MotionDemo_Run();

    /* ===== 舵机自检：左右摆动一次 ===== */
    Servo_SelfTest();

    /* ===== 运动演示（死循环） ===== */

    // while (1) {
    //     // uart_puts("zero\r\n");
    //     // Servo_SetPulse(10000);   // 10ms 高电平（占空比 50%，远超舵机行程）
    //     // delay_ms(1500);
    //     // Servo_SetPulse(1500);    // 中位
    //     // delay_ms(1500);

    //     uart_puts("left\r\n");
    //     Servo_SetPulse(1000);   // 1000us = 左
    //     delay_ms(1500);
    //     uart_puts("zero\r\n");
    //     Servo_SetPulse(1500);   // 1500us = 中
    //     delay_ms(1500);
    //     uart_puts("right\r\n");
    //     Servo_SetPulse(2000);   // 2000us = 右
    //     delay_ms(1500);
    //     /* ---------- 1. 直线前进 / 刹车 / 后退 ---------- */
    //     uart_puts("[1] 前进 60% x2s\r\n");
    //     Motor_SetSpeed(600);
    //     delay_ms(2000);

    //     uart_puts("[2] 刹车(短路制动)\r\n");
    //     Motor_EmergencyBrake();
    //     LED_ON(); delay_ms(800); LED_OFF();
    //     Motor_ReleaseBrake();
    // }

    

    // while(1)
    // {
    //     uart_puts("循环测试，舵机转向\r\n");

    //     uart_puts("zero\r\n");
    //     Servo_SetAngle(0);
    //     delay_ms(2000);

    //     uart_puts("left\r\n");
    //     Servo_SetAngle(-SERVO_MAX_ANGLE_DEG);
    //     delay_ms(2000);

    //     uart_puts("zero\r\n");
    //     Servo_SetAngle(0);
    //     delay_ms(2000);

    //     uart_puts("right\r\n");
    //     Servo_SetAngle(SERVO_MAX_ANGLE_DEG);
    //     delay_ms(2000);
        
    // }
    MotionDemo_Run();

    return 0;   /* 不会到这里 */
}

// #include "stm32f407_regs.h"

// int main(void)
// {
//     // =========【1. 最先关闭JTAG，释放PB3 PB4】=========
//     RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
//     SYSCFG->PMC &= ~(0x7UL << 24);
//     SYSCFG->PMC |=  (0x2UL << 24);

//     // =========【2. 开启GPIOA GPIOB时钟】=========
//     RCC->AHB1ENR |= (1U << 0); // GPIOA
//     RCC->AHB1ENR |= (1U << 1); // GPIOB

//     // PB3 STBY 输出
//     GPIOB->MODER &= ~(3U << (3*2));
//     GPIOB->MODER |=  (1U << (3*2));
//     GPIOB->BSRR = (1U << 3); // STBY=高，使能TB6612

//     // PB0 AIN1 PB1 AIN2 输出
//     GPIOB->MODER &= ~((3U << 0*2)|(3U <<1*2));
//     GPIOB->MODER |=  ((1U << 0*2)|(1U <<1*2));
//     GPIOB->BSRR = 1U <<0;          //AIN1=高
//     GPIOB->BSRR = (1U << (1 + 16));//AIN2=低 正转

//     // // =========【PA6 TIM3_CH1 PWM配置】=========
//     // RCC->APB1ENR |= (1U <<1); //TIM3时钟
//     // // PA6复用功能AF2(TIM3_CH1)
//     // GPIOA->MODER &= ~(3U << (6*2));
//     // GPIOA->MODER |=  (2U << (6*2));
//     // // PA6属于AFRL（引脚0~7）
//     // GPIOA->AFRL &= ~(0xFU << (6*4));
//     // GPIOA->AFRL |=  (2U << (6*4));

//     // 原来TIM3 PWM全部注释掉，换成下面GPIO配置
//     // PA6 普通GPIO输出高电平
//     RCC->AHB1ENR |= (1U << 0); //GPIOA时钟
//     GPIOA->MODER &= ~(3U << (6*2));
//     GPIOA->MODER |=  (1U << (6*2)); //输出模式
//     GPIOA->BSRR = 1U <<6; //PA6=3.3V，PWMA恒高


//     TIM3->PSC = 83;
//     TIM3->ARR = 49;
//     TIM3->CCR1 = 25; //50%占空比
//     TIM3->CCMR1 |= (6U <<4); //PWM模式1
//     TIM3->CCER |= 1U; //开启CH1输出
//     TIM3->CR1 |= 1U; //启动TIM3

//     while(1)
//     {
//         //循环空转
//     }
// }

