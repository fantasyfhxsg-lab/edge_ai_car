/**
 * servo_driver.c - 舵机驱动实现（MG996R，TIM1_CH1/PA8）
 *
 * ═══════════ 舵机控制原理 ═══════════
 * 舵机不是"转多快"而是"转到位"：内部电位器闭环，
 * 输入脉冲宽度(1~2ms)决定输出轴角度，50Hz 周期重复即可保持。
 *   脉宽 1.0ms -> -90°（左极限）
 *   脉宽 1.5ms ->   0°（中位）
 *   脉宽 2.0ms -> +90°（右极限）
 * 本工程把转角限制在 ±30°（SERVO_MAX_ANGLE_DEG），
 * 对应脉宽 1250us ~ 1750us，对阿克曼转向足够且不堵转。
 *
 * 频率计算：
 *   TIM1 时钟 = APB2×2 = 168MHz；PSC=167 -> 1MHz（每 tick = 1us）；
 *   ARR=19999 -> 周期 20000us = 50Hz。
 *   CCR 数值直接就是脉冲宽度微秒数：CCR=1500 -> 1.5ms -> 中位。
 *
 * 高级定时器注意：TIM1/TIM8 是"高级定时器"，输出 PWM 前
 * 必须置 BDTR.MOE=1（主输出使能），否则引脚保持低电平——经典坑。
 */
#include "servo_driver.h"

static sint8 g_current_angle = 0;

/* ===== 角度→脉冲 ===== */
static uint16 AngleToPulse(sint8 angle)
{
    sint32 pulse;

    if (angle > SERVO_MAX_ANGLE_DEG)  angle = SERVO_MAX_ANGLE_DEG;
    if (angle < -SERVO_MAX_ANGLE_DEG) angle = -SERVO_MAX_ANGLE_DEG;

    // pulse = SERVO_CENTER_PULSE_US +
    //         ((sint32)angle * (SERVO_MAX_LEFT_PULSE_US - SERVO_CENTER_PULSE_US)) / SERVO_MAX_ANGLE_DEG;
    pulse = (sint32)SERVO_CENTER_PULSE_US +
        ((sint32)angle * ((sint32)SERVO_MAX_LEFT_PULSE_US - (sint32)SERVO_CENTER_PULSE_US)) / (sint32)SERVO_MAX_ANGLE_DEG;


    if (pulse > (sint32)SERVO_MAX_LEFT_PULSE_US)  pulse = (sint32)SERVO_MAX_LEFT_PULSE_US;
    if (pulse < (sint32)SERVO_MAX_RIGHT_PULSE_US) pulse = (sint32)SERVO_MAX_RIGHT_PULSE_US;

    return (uint16)pulse;
}

void Servo_Init(void)
{
    /* 定时器由 main.c 初始化并启动；这里只回中 */
    Servo_SetAngle(0);
}

void Servo_SetAngle(sint8 angle)
{
    uint16 pulse_us;

    if (angle > SERVO_MAX_ANGLE_DEG)  angle = SERVO_MAX_ANGLE_DEG;
    if (angle < -SERVO_MAX_ANGLE_DEG) angle = -SERVO_MAX_ANGLE_DEG;

    g_current_angle = angle;
    pulse_us = AngleToPulse(angle);
    TIM1->CCR1 = (uint32)pulse_us;   /* 1MHz -> 1 计数 = 1us */
}

sint8 Servo_GetAngle(void)
{
    return g_current_angle;
}

void Servo_SetPulse(uint16 pulse_us)
{
    if (pulse_us > SERVO_MAX_LEFT_PULSE_US)  pulse_us = SERVO_MAX_LEFT_PULSE_US;
    if (pulse_us < SERVO_MAX_RIGHT_PULSE_US) pulse_us = SERVO_MAX_RIGHT_PULSE_US;
    TIM1->CCR1 = (uint32)pulse_us;
}

/* ===== 自检：左右摆一次回中 ===== */
boolean Servo_SelfTest(void)
{
    if (!(TIM1->CR1 & TIM_CR1_CEN)) {
        return FALSE;
    }
    Servo_SetAngle(SERVO_MAX_ANGLE_DEG);
    delay_ms(300);
    Servo_SetAngle(-SERVO_MAX_ANGLE_DEG);
    delay_ms(300);
    Servo_SetAngle(0);
    return TRUE;
}
