// /**
//  * main.c - 主程序（适配 M144Z-M4 / 正点原子 STM32F407 Mini板，LQFP144）
//  *
//  * ═════════════════════ 代码阅读地图（先看这里）═════════════════════
//  *
//  * 数据流（CAN 遥控）：
//  *
//  *   USB-CAN适配器 ──CAN总线──> TJA1050 ──> CAN1(PA11/12)
//  *       │                                          │
//  *       │                                   Can_ProcessRx() 10ms轮询
//  *       │                                          ▼
//  *       │                              App_CanRxCallback()  ← 中断式回调
//  *       │        0x100控制帧 ──> g_control{速度,转向,制动} + g_control_received=TRUE
//  *       │        0x102AI心跳 ──> g_last_ai_heartbeat_tick 刷新（500ms超时刹车）
//  *       ▼                                          ▼
//  *   Task_20ms(20ms)  ──> Motor_SetSpeed(duty) + Servo_SetAngle(angle)
//  *       │                                          │
//  *       │                                  TIM3 CCR1/CCR2 (PA6/PA7 PWM)
//  *       │                                  TIM1 CCR1 (PA8 舵机脉宽)
//  *       ▼
//  *   Task_10ms ──> Can_Send(0x101 状态帧)   Task_100ms ──> Can_Send(0x103 心跳)
//  *
//  * 时间基准：
//  *   HSE 8MHz ──PLL──> SYSCLK 168MHz ──> AHB 168MHz
//  *        └── APB1 = 42MHz（TIM3/TIM4/CAN1/USART1 挂在 APB1，TIM 实际 84MHz）
//  *        └── APB2 = 84MHz（TIM1/TIM8 挂在 APB2，TIM 实际 168MHz）
//  *   外设频率是理解下面每个 PSC/ARR 数值的起点。
//  *
//  * 功能：
//  *   1. 时钟 168MHz、SysTick、USART1、LED 初始化
//  *   2. TIM3 双通道 PWM 20kHz -> TB6612（PA6/PA7）
//  *   3. TIM1 50Hz -> MG996R 舵机（PA8）
//  *   4. TIM4/TIM8 编码器模式（PD12/PD13 左轮, PC6/PC7 右轮）
//  *   5. CAN1 500kbps（PA11/PA12）
//  *   6. 上电 demo：前进->停->后退->停->舵机摆角（先跑起来）
//  *   7. 主循环 10/20/100ms 任务：CAN 收发、心跳监控、控制执行
//  *
//  * 注意（M144Z-M4 Mini板）：
//  *   - 板载 USB 转串口（CH340 ↔ USART1 PA9/PA10，115200）：
//  *     跳线保持在"USB串口"位置即可用板载 USB 口看日志，无需外接 USB-TTL
//  *   - 板载 USB SLAVE 占用 PA11/PA12（OTG_FS），与 CAN1 冲突：
//  *     用 CAN1 时不要插 USB SLAVE 口！
//  *   - 无板载 CAN 收发器：PA11/PA12 需外接 TJA1050 模块
//  *   - 用户 LED：LED0=PF9(红)、LED1=PF10(绿)，低电平点亮
//  *   - PD12/PD13(FSMC_A11/A12) 与 PC6/PC7(DCMI_D0/D1)：
//  *     不接 TFTLCD/摄像头模块时可用作编码器，接了会冲突
//  *   - BOOT0=0（Flash 启动；一键串口下载由板载 CH340 自动控制）
//  *   - 舵机 5-6V 独立供电，严禁从板子 3.3V 取电
//  */

// /* ===== 只包含抽象层头文件 ===== */
// #include "platform.h"
// #include "can_protocol.h"
// #include "motor_driver.h"
// #include "servo_driver.h"
// #include "can_driver.h"
// #include "encoder.h"
// #include <stddef.h>

// /* ===== 应用层全局变量 ===== */
// static volatile CanControlFrame g_control = {0};
// static volatile boolean g_control_received = FALSE;
// static volatile boolean g_ai_heartbeat_seen = FALSE;   /* 收到过 AI 心跳才启用超时保护 */

// static uint8  g_status_word = STATUS_NORMAL;
// static uint8  g_fault_code = FAULT_NONE;
// static sint8  g_current_speed = 0;

// static uint32 g_last_ai_heartbeat_tick = 0;
// static uint8  g_stm32_heartbeat_counter = 0;

// /* 编码器数值缓存（供状态帧发送） */
// static sint16 g_enc_left = 0;
// static sint16 g_enc_right = 0;

// /* ================================================================
//  *  时钟 / 平台基础服务（寄存器级）
//  * ================================================================ */
// void SystemClock_Config(void)
// {
//     /* 使能 HSE(8MHz) */
//     RCC->CR |= (1UL << 16);
//     uint32 timeout = 1000000;
//     while (!(RCC->CR & (1UL << 17))) {   /* HSERDY */
//         if (--timeout == 0) break;
//     }

//     /* 等待 PLL 就绪标志复位 */
//     while (RCC->CR & (1UL << 25)) {}

//     /* PLL: VCO = 8MHz / M(8) * N(336) = 336MHz
//      *      PLLCLK = 336 / P(2) = 168MHz
//      *      Q = 7 -> 48MHz (USB 用)
//      * PLLCFGR: PLLM=8 | PLLN=336<<6 | PLLP=0(÷2)<<16 | PLLQ=7<<24 | PLLSRC=HSE(1)<<22
//      */
//     RCC->PLLCFGR = (8UL) | (336UL << 6) | (0UL << 16) | (7UL << 24) | (1UL << 22);

//     /* 使能 PLL */
//     RCC->CR |= (1UL << 24);
//     timeout = 1000000;
//     while (!(RCC->CR & (1UL << 25))) {   /* PLLRDY */
//         if (--timeout == 0) break;
//     }

//     /* Flash 等待周期 5WS + 预取/缓存使能 */
//     *FLASH_ACR &= ~FLASH_ACR_LATENCY_MASK;
//     *FLASH_ACR |= FLASH_ACR_LATENCY_5WS | FLASH_ACR_ICEN | FLASH_ACR_DCEN;

//     /* 总线分频：AHB=1, APB1=4(42MHz), APB2=2(84MHz)
//      * CFGR: HPRE=0(÷1) | PPRE1=101(÷4)<<10 | PPRE2=100(÷2)<<13 | SW=PLL(10)<<0
//      */
//     RCC->CFGR = (0UL) | (5UL << 10) | (4UL << 13);
//     RCC->CFGR = (0UL) | (5UL << 10) | (4UL << 13) | (2UL << 0);

//     /* 等待 PLL 切换完成 */
//     timeout = 1000000;
//     while (((RCC->CFGR >> 2) & 0x3) != 0x2) {
//         if (--timeout == 0) break;
//     }
// }

// void SysTick_Init(void)
// {
//     SysTick->RVR = 168000UL - 1UL;   /* 168MHz / 168000 = 1ms */
//     SysTick->CVR = 0;
//     SysTick->CSR = SYSTICK_CSR_CLKSOURCE | SYSTICK_CSR_TICKINT | SYSTICK_CSR_ENABLE;
// }

// static volatile uint32 g_ticks = 0;
// void SysTick_Handler(void)
// {
//     g_ticks++;
// }

// uint32 millis(void)
// {
//     return g_ticks;
// }

// void delay_ms(uint32 ms)
// {
//     uint32 start = millis();
//     while ((millis() - start) < ms) {}
// }

// /* ================================================================
//  *  USART1 调试串口（PA9=TX, PA10=RX, 115200 8N1）
//  * ================================================================ */
// void UART1_Init(void)
// {
//     gpio_enable_clock(GPIOA);
//     gpio_mode(GPIOA, GPIO_PIN_9 | GPIO_PIN_10, GPIO_MODE_AF);
//     gpio_af(GPIOA, GPIO_PIN_9, 7);
//     gpio_af(GPIOA, GPIO_PIN_10, 7);

//     RCC->APB2ENR |= RCC_USART1EN;

//     /* 波特率 115200: USARTDIV = 84MHz / 115200 = 729.167
//      * BRR = 729<<4 | 3 = 11667 = 0x2D93 */
//     USART1->BRR = 0x2D93;

//     USART1->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
// }

// void uart_putc(char c)
// {
//     while (!(USART1->SR & USART_SR_TXE)) {}
//     USART1->DR = (uint32)(uint8)c;
// }

// void uart_puts(const char *s)
// {
//     while (*s) {
//         uart_putc(*s++);
//     }
// }

// void uart_printf(const char *fmt, ...)
// {
//     char buf[128];
//     va_list ap;
//     va_start(ap, fmt);
//     vsnprintf(buf, sizeof(buf), fmt, ap);
//     va_end(ap);
//     uart_puts(buf);
// }

// /* ================================================================
//  *  外设初始化（寄存器级，替代 CubeMX）
//  * ================================================================ */

// /* TIM3: 双通道 PWM 20kHz（TB6612 PWMA/PWMB）
//  *  APB1=42MHz, TIM3 时钟=84MHz, PSC=83 -> 1MHz, ARR=49 -> 20kHz */
// static void MX_TIM3_PWM_Init(void)
// {
//     RCC->APB1ENR |= RCC_TIM3EN;

//     gpio_enable_clock(GPIOA);
//     gpio_mode(GPIOA, GPIO_PIN_6 | GPIO_PIN_7, GPIO_MODE_AF);
//     gpio_af(GPIOA, GPIO_PIN_6, 2);
//     gpio_af(GPIOA, GPIO_PIN_7, 2);

//     TIM3->PSC = 83;
//     TIM3->ARR = 49;
//     TIM3->CCMR1 = TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE |   /* CH1: PWM mode 1 */
//                   TIM_CCMR1_OC2M | TIM_CCMR1_OC2PE;    /* CH2: PWM mode 1 */
//     TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E;
//     TIM3->CCR1 = 0;
//     TIM3->CCR2 = 0;
//     TIM3->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
// }

// /* TIM1: 舵机 PWM 50Hz（PA8=TIM1_CH1, AF1）
//  *  APB2=84MHz, TIM1 时钟=168MHz, PSC=167 -> 1MHz, ARR=19999 -> 50Hz
//  *  高级定时器必须置 BDTR.MOE */
// static void MX_TIM1_PWM_Init(void)
// {
//     RCC->APB2ENR |= RCC_TIM1EN;

//     gpio_enable_clock(GPIOA);
//     gpio_mode(GPIOA, GPIO_PIN_8, GPIO_MODE_AF);
//     gpio_af(GPIOA, GPIO_PIN_8, 1);

//     TIM1->PSC = 167;
//     TIM1->ARR = 19999;
//     TIM1->CCMR1 = TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE;
//     TIM1->CCER = TIM_CCER_CC1E;
//     TIM1->CCR1 = 1500;                 /* 中位 */
//     TIM1->BDTR = TIM_BDTR_MOE;         /* 主输出使能，必须有 */
//     TIM1->CR1 = TIM_CR1_CEN | TIM_CR1_ARPE;
// }

// /* LED: LED0=PF9（M144Z-M4 Mini板，低电平点亮） */
// static void MX_LED_Init(void)
// {
//     gpio_enable_clock(GPIOF);
//     gpio_mode(GPIOF, GPIO_PIN_9, GPIO_MODE_OUTPUT);
//     LED_OFF();
// }

// /* ================================================================
//  *  CAN 接收回调（应用层）
//  * ================================================================ */
// static void App_CanRxCallback(uint16 can_id, const uint8* data, uint8 len)
// {
//     switch (can_id)
//     {
//         case CAN_ID_CONTROL:
//             if (len >= 4)
//             {
//                 g_control.control_word = data[0];
//                 g_control.target_speed = (sint8)data[1];
//                 g_control.steering = (sint8)data[2];
//                 g_control.brake_cmd = data[3];
//                 g_control_received = TRUE;
//             }
//             break;

//         case CAN_ID_HEARTBEAT_AI:
//             g_last_ai_heartbeat_tick = millis();
//             g_ai_heartbeat_seen = TRUE;
//             break;

//         default:
//             break;
//     }
// }

// /* ================================================================
//  *  任务函数（对应脚手架 10/20/100ms 任务）
//  * ================================================================ */
// static void Task_10ms(void)
// {
//     uint8 data[8];

//     /* 1. 轮询接收 CAN */
//     Can_ProcessRx();

//     /* 2. 发送状态帧（0x101） */
//     data[0] = g_status_word;
//     data[1] = (uint8)g_current_speed;
//     data[2] = 122;                    /* 电池电压 12.2V（示例，未接ADC） */
//     data[3] = g_fault_code;
//     data[4] = (uint8)((uint16)g_enc_left >> 8);
//     data[5] = (uint8)((uint16)g_enc_left & 0xFF);
//     data[6] = (uint8)((uint16)g_enc_right >> 8);
//     data[7] = (uint8)((uint16)g_enc_right & 0xFF);
//     Can_Send(CAN_ID_STATUS, data, 8);
// }

// static void Task_20ms(void)
// {
//     sint16 duty;
//     sint16 dl, dr;
//     float32 rpm_avg;

//     /* 1. 编码器测速（左右轮各取一次增量，避免重复读） */
//     dl = Encoder_GetDelta();
//     dr = Encoder_GetDeltaRight();
//     g_enc_left = Encoder_GetCount();
//     g_enc_right = Encoder_GetCountRight();
//     rpm_avg = ((float32)dl + (float32)dr) / 2.0f * 3000.0f / (float32)ENCODER_PPR;
//     g_current_speed = (sint8)(rpm_avg / 10.0f);

//     /* 2. 控制执行 */
//     if (g_status_word == STATUS_FAULT) {
//         Motor_EmergencyBrake();
//         return;
//     }

//     if (g_control.brake_cmd == BRAKE_EMERGENCY) {
//         Motor_EmergencyBrake();
//         g_status_word = STATUS_BRAKE;
//     }
//     else if (g_control.control_word == CTRL_ENABLE) {
//         /* 开环：速度 -100~100 -> 占空比 ×10（-1000~1000）
//          * PID 闭环调好后，把这里换成 App_MotorPID() 输出即可 */
//         duty = (sint16)g_control.target_speed * 10;
//         Motor_SetSpeed(duty);
//         /* 转向 -100~100 -> 舵机 -30~+30 度 */
//         Servo_SetAngle((sint8)((sint16)g_control.steering * SERVO_MAX_ANGLE_DEG / 100));
//         g_status_word = STATUS_NORMAL;
//     }
//     else {
//         Motor_SetSpeed(0);
//     }
// }

// static void Task_100ms(void)
// {
//     /* 1. AI 心跳监控（收到过心跳才启用超时保护） */
//     if (g_ai_heartbeat_seen) {
//         if ((millis() - g_last_ai_heartbeat_tick) > HEARTBEAT_TIMEOUT_MS) {
//             g_status_word = STATUS_FAULT;
//             g_fault_code |= FAULT_AI_HEARTBEAT;
//         }
//         else if ((g_status_word == STATUS_FAULT) && (g_fault_code & FAULT_AI_HEARTBEAT)) {
//             g_fault_code &= ~FAULT_AI_HEARTBEAT;
//             if (g_fault_code == FAULT_NONE) {
//                 g_status_word = STATUS_NORMAL;
//                 Motor_ReleaseBrake();
//             }
//         }
//     }

//     /* 2. 发送 STM32 心跳（0x103） */
//     Can_SendHeartbeat(g_stm32_heartbeat_counter++);

//     /* 3. 总线错误监控 */
//     if (Can_IsBusOff()) {
//         uart_printf("[WARN] CAN Bus-Off! TEC=%u REC=%u\r\n",
//                     Can_GetTxErrorCount(), Can_GetRxErrorCount());
//     }

//     /* 4. LED 闪烁 */
//     LED_OFF();
//     delay_ms(30);
//     LED_ON();
// }

// /* ================================================================
//  *  上电 Demo：先让小车跑起来（不依赖 CAN/AI 板）
//  * ================================================================ */
// static void Demo_Run(void)
// {
//     uart_printf("\r\n=== edge_ai_car STM32 demo (M144Z-M4 v2.1) ===\r\n");
//     uart_printf("PWM=20kHz TB6612 | Servo=50Hz MG996R | CAN=500kbps\r\n\r\n");

//     uart_printf("[demo] 前进 40% x2s\r\n");
//     Motor_SetSpeed(400);
//     delay_ms(2000);

//     uart_printf("[demo] 刹车\r\n");
//     Motor_EmergencyBrake();
//     delay_ms(1000);

//     uart_printf("[demo] 后退 40% x2s\r\n");
//     Motor_SetSpeed(-400);
//     delay_ms(2000);

//     uart_printf("[demo] 刹车\r\n");
//     Motor_EmergencyBrake();
//     delay_ms(1000);

//     uart_printf("[demo] 舵机 +30 -> -30 -> 0\r\n");
//     Servo_SetAngle(30);
//     delay_ms(800);
//     Servo_SetAngle(-30);
//     delay_ms(800);
//     Servo_SetAngle(0);
//     delay_ms(500);

//     Motor_ReleaseBrake();
//     uart_printf("[demo] 完成，等待 CAN 控制...\r\n");
// }

// /* ================================================================
//  *  newlib 堆支持（-specs=nano.specs 需要 _sbrk，勿删）
//  * ================================================================ */
// extern char end;   /* 由链接脚本定义 */
// void *_sbrk(ptrdiff_t incr)
// {
//     static char *heap_end = 0;
//     char *prev_heap_end;

//     if (heap_end == 0) {
//         heap_end = &end;
//     }
//     prev_heap_end = heap_end;
//     heap_end += incr;
//     return (void *)prev_heap_end;
// }

// /* ================================================================
//  *  main
//  * ================================================================ */
// int main(void)
// {
//     /* ===== 平台基础 ===== */
//     SystemClock_Config();
//     SysTick_Init();
//     UART1_Init();
//     MX_LED_Init();

//     /* ===== 外设 ===== */
//     MX_TIM3_PWM_Init();     /* TB6612 PWM */
//     MX_TIM1_PWM_Init();     /* 舵机 */
//     Encoder_Init();         /* TIM4/TIM8 编码器 */

//     /* ===== 驱动层 ===== */
//     Motor_Init();
//     Servo_Init();
//     Can_Init();

//     /* ===== 注册 CAN 回调 ===== */
//     Can_RegisterRxCallback(App_CanRxCallback);

//     uart_printf("edge_ai_car STM32 boot OK @168MHz\r\n");

//     /* 自检（舵机会左右摆动一次） */
//     Servo_SelfTest();
//     (void)Motor_SelfTest();
//     (void)Encoder_SelfTest();

//     /* ===== 上电 Demo ===== */
//     Demo_Run();

//     g_last_ai_heartbeat_tick = millis();

//     /* ===== 主循环：非阻塞时间片轮询调度 =====
//      * 三个任务各自记录上次执行时刻，用 millis() 差值判断是否到期。
//      * 这是"裸机调度器"的最简形态：没有中断抢占业务逻辑，
//      * 每个任务都在 while(1) 里轮转，任何任务超时只影响自己。
//      *   Task_10ms  : CAN 轮询接收 + 回状态帧（0x101）
//      *   Task_20ms  : 编码器测速 + 执行控制（电机/舵机）
//      *   Task_100ms : AI 心跳监控 + 回心跳（0x103）+ LED 闪
//      */
//     uint32 last_10ms = 0, last_20ms = 0, last_100ms = 0;

//     while (1)
//     {
//         uint32 now = millis();

//         if (now - last_10ms >= 10) {
//             last_10ms = now;
//             Task_10ms();
//         }
//         if (now - last_20ms >= 20) {
//             last_20ms = now;
//             Task_20ms();
//         }
//         if (now - last_100ms >= 100) {
//             last_100ms = now;
//             Task_100ms();
//         }
//     }
// }
